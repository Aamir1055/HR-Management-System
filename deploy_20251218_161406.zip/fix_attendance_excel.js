/**
 * Fix Attendance Excel File
 * Reads your Excel and creates a properly formatted version
 */

const XLSX = require('xlsx');
const path = require('path');

async function fixAttendanceExcel(inputFile) {
  try {
    console.log('🔧 FIXING ATTENDANCE EXCEL FILE');
    console.log('===============================');
    console.log(`📄 Input file: ${inputFile}`);
    console.log('');

    // Read the Excel file
    const workbook = XLSX.readFile(inputFile);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];

    console.log('📊 Analyzing Excel structure...');
    
    // Get the range
    const range = XLSX.utils.decode_range(sheet['!ref']);
    console.log(`   Rows: ${range.s.r} to ${range.e.r}`);
    console.log(`   Columns: ${range.s.c} to ${range.e.c}`);
    console.log('');

    // Try reading with different options
    console.log('🔍 Trying different read methods...');
    
    // Method 1: Default
    const data1 = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    console.log('   Method 1 (default):');
    console.log('   Columns:', data1[0] ? Object.keys(data1[0]) : 'No data');
    
    // Method 2: With header row 0
    const data2 = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
    console.log('   Method 2 (header: 1):');
    console.log('   First row:', data2[0]);
    console.log('   Second row:', data2[1]);
    
    // Method 3: Skip first row
    const data3 = XLSX.utils.sheet_to_json(sheet, { range: 1, defval: '' });
    console.log('   Method 3 (skip first row):');
    console.log('   Columns:', data3[0] ? Object.keys(data3[0]) : 'No data');
    console.log('');

    // Find the header row
    console.log('🔎 Finding header row...');
    let headerRowIndex = -1;
    let headers = [];
    
    for (let i = 0; i <= Math.min(5, data2.length); i++) {
      const row = data2[i];
      if (row && Array.isArray(row)) {
        const hasEmployeeId = row.some(cell => 
          cell && typeof cell === 'string' && 
          (cell.includes('Employee') || cell.includes('employee') || cell.includes('Emp'))
        );
        
        if (hasEmployeeId) {
          headerRowIndex = i;
          headers = row;
          console.log(`   ✅ Found header row at index ${i}`);
          console.log(`   Headers: ${headers.join(', ')}`);
          break;
        }
      }
    }

    if (headerRowIndex === -1) {
      console.log('   ❌ Could not find header row automatically');
      console.log('   First 3 rows:');
      data2.slice(0, 3).forEach((row, i) => {
        console.log(`   Row ${i}:`, row);
      });
      return;
    }

    // Read data starting from the row after headers
    const attendanceData = XLSX.utils.sheet_to_json(sheet, {
      range: headerRowIndex,
      defval: '',
      raw: false
    });

    console.log('');
    console.log('📊 Extracted Data:');
    console.log(`   Total records: ${attendanceData.length}`);
    console.log(`   Columns: ${Object.keys(attendanceData[0] || {}).join(', ')}`);
    console.log('   Sample records:');
    attendanceData.slice(0, 3).forEach((record, i) => {
      console.log(`   ${i + 1}. Employee: ${record['Employee ID'] || record['EmployeeID']}, Date: ${record['Date']}`);
    });

    // Create a fixed version
    console.log('');
    console.log('💾 Creating fixed Excel file...');
    
    const fixedData = attendanceData.map(row => ({
      'Employee ID': row['Employee ID'] || row['EmployeeID'] || row['employee_id'] || '',
      'Name': row['Name'] || row['name'] || '',
      'Date': row['Date'] || row['date'] || '',
      'Punch In': row['Punch In'] || row['PunchIn'] || row['punch_in'] || '0:00:00',
      'Punch Out': row['Punch Out'] || row['PunchOut'] || row['punch_out'] || '0:00:00'
    }));

    const newWorkbook = XLSX.utils.book_new();
    const newSheet = XLSX.utils.json_to_sheet(fixedData);
    XLSX.utils.book_append_sheet(newWorkbook, newSheet, 'Attendance');

    const outputFile = inputFile.replace('.xlsx', '_FIXED.xlsx').replace('.xls', '_FIXED.xlsx');
    XLSX.writeFile(newWorkbook, outputFile);

    console.log(`   ✅ Fixed file created: ${outputFile}`);
    console.log('');
    console.log('🎉 SUCCESS!');
    console.log('===========');
    console.log('Use the _FIXED.xlsx file for upload.');
    console.log('It has properly formatted headers and data.');

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

// Usage
const args = process.argv.slice(2);
if (args.length === 0) {
  console.log('Usage: node fix_attendance_excel.js <excel_file_path>');
  console.log('');
  console.log('Example:');
  console.log('  node fix_attendance_excel.js "C:/Users/user/Downloads/attendance.xlsx"');
  console.log('');
  console.log('This will create a fixed version: attendance_FIXED.xlsx');
  process.exit(1);
}

fixAttendanceExcel(args[0]);