const mysql = require('mysql2/promise');
require('dotenv').config();

async function testAPI() {
  const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'payroll_system2',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

  try {
    console.log('Testing user_roles table...');
    
    // Test the user_roles table directly
    const [rows] = await pool.query('SELECT * FROM user_roles ORDER BY name');
    console.log('✅ User roles found:', rows);
    
    // Test the API endpoint by simulating what the repository does
    const RoleRepository = require('./repositories/RoleRepository');
    const roleRepo = new RoleRepository(pool);
    
    console.log('\nTesting RoleRepository.findAll()...');
    const roles = await roleRepo.findAll();
    console.log('✅ Repository result:', roles);
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error('Stack:', error.stack);
  } finally {
    await pool.end();
  }
}

testAPI();