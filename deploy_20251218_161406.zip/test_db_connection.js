const mysql = require('mysql2/promise');

async function testConnection() {
  try {
    const connection = await mysql.createConnection({
      host: 'localhost',
      port: 3306,
      user: 'root',
      password: '',
      database: 'payroll_system2'
    });
    
    console.log('✅ Database connection successful');
    
    // Test employee table structure
    const [columns] = await connection.query('DESCRIBE employees');
    console.log('📋 Employee table columns:');
    columns.forEach(col => {
      console.log(`  - ${col.Field} (${col.Type}) ${col.Null === 'YES' ? 'NULL' : 'NOT NULL'} ${col.Key ? `[${col.Key}]` : ''}`);
    });
    
    // Test a simple select query
    const [testQuery] = await connection.query('SELECT COUNT(*) as total FROM employees LIMIT 1');
    console.log(`📊 Employee count: ${testQuery[0].total}`);
    
    await connection.end();
  } catch (error) {
    console.error('❌ Database error:', error.message);
  }
}

testConnection();
