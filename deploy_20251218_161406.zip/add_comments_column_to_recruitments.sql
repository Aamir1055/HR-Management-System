-- Add comments column to recruitments table
-- This migration adds the comments field to support additional candidate notes

ALTER TABLE `recruitments` 
ADD COLUMN `comments` TEXT NULL COMMENT 'Additional comments or notes about the candidate' 
AFTER `nationality`;

-- Verify the column was added
DESCRIBE `recruitments`;