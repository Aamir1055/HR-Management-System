-- =====================================================
-- COMPLETE DATABASE MIGRATION SCRIPT
-- HR Management System - Master Data & Recruitment Updates
-- =====================================================
-- This script contains all SQL changes made for:
-- 1. Role Management System
-- 2. Recruitment Master Data (Sources, Pipelines, Platforms)
-- 3. Recruitment Form Updates
-- 4. Master Data Management Integration
-- =====================================================

-- =====================================================
-- 1. ROLES MASTER TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT 'Role name',
  `description` text DEFAULT NULL COMMENT 'Role description',
  `isActive` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Active status (1=active, 0=inactive)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record update timestamp',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='User roles master data';

-- Insert default roles
INSERT IGNORE INTO `roles` (`name`, `description`) VALUES
('Admin', 'System administrator with full access'),
('HR Manager', 'Human resources manager'),
('Employee', 'Regular employee'),
('Manager', 'Department or team manager'),
('Recruiter', 'Recruitment specialist');

-- =====================================================
-- 2. RECRUITMENT SOURCES MASTER TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `recruitment_sources` (
  `sourceId` int(11) NOT NULL AUTO_INCREMENT,
  `sourceName` varchar(100) NOT NULL COMMENT 'Recruitment source name',
  `description` text DEFAULT NULL COMMENT 'Optional description',
  `isActive` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Active status',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record update timestamp',
  PRIMARY KEY (`sourceId`),
  UNIQUE KEY `unique_source_name` (`sourceName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Recruitment sources master data';

-- Insert default recruitment sources
INSERT IGNORE INTO `recruitment_sources` (`sourceName`, `description`) VALUES
('Indeed', 'Job applications from Indeed job portal'),
('Candidate Reference', 'Applications through candidate referrals'),
('Employee Reference', 'Applications through employee referrals'),
('Walk-In', 'Direct walk-in applications'),
('LinkedIn', 'Applications from LinkedIn job postings'),
('Company Website', 'Direct applications from company website'),
('Job Fair', 'Applications from job fairs and career events'),
('Recruitment Agency', 'Applications through external recruitment agencies');

-- =====================================================
-- 3. RECRUITMENT PIPELINES MASTER TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `recruitment_pipelines` (
  `pipelineId` int(11) NOT NULL AUTO_INCREMENT,
  `pipelineName` varchar(100) NOT NULL COMMENT 'Pipeline stage name',
  `description` text DEFAULT NULL COMMENT 'Optional description',
  `stageOrder` int(11) NOT NULL DEFAULT 0 COMMENT 'Order of stage in pipeline',
  `isActive` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Active status',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record update timestamp',
  PRIMARY KEY (`pipelineId`),
  UNIQUE KEY `unique_pipeline_name` (`pipelineName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Recruitment pipeline stages master data';

-- Insert default recruitment pipeline stages
INSERT IGNORE INTO `recruitment_pipelines` (`pipelineName`, `description`, `stageOrder`) VALUES
('Application Received', 'Initial application received', 1),
('HR Screening', 'Initial HR screening stage', 2),
('Screening Reject', 'Rejected at screening stage', 3),
('Technical Assessment', 'Technical skills assessment', 4),
('R1', 'First round of interviews', 5),
('R1 Reject', 'Rejected after first round', 6),
('R2', 'Second round of interviews', 7),
('R2 Reject', 'Rejected after second round', 8),
('Final Interview', 'Final interview with management', 9),
('Background Check', 'Background verification process', 10),
('Offered', 'Job offer extended to candidate', 11),
('Offer Accepted', 'Candidate accepted the offer', 12),
('Offer Rejected', 'Candidate rejected the offer', 13),
('Onboarded', 'Candidate successfully onboarded', 14);

-- =====================================================
-- 4. RECRUITMENT PLATFORMS MASTER TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `recruitment_platforms` (
  `platformId` int(11) NOT NULL AUTO_INCREMENT,
  `platformName` varchar(100) NOT NULL COMMENT 'Platform name',
  `description` text DEFAULT NULL COMMENT 'Optional description',
  `isActive` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Active status',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record update timestamp',
  PRIMARY KEY (`platformId`),
  UNIQUE KEY `unique_platform_name` (`platformName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Recruitment platforms master data';

-- Insert default recruitment platforms
INSERT IGNORE INTO `recruitment_platforms` (`platformName`, `description`) VALUES
('National Stock Exchange', 'National Stock Exchange trading platform'),
('Forex', 'Foreign exchange trading platform'),
('Commodities', 'Commodities trading platform'),
('Derivatives', 'Derivatives trading platform'),
('Mutual Funds', 'Mutual funds platform'),
('Insurance', 'Insurance products platform');

-- =====================================================
-- 5. UPDATE EXISTING RECRUITMENTS TABLE
-- =====================================================
-- Add new columns to recruitments table if they don't exist

-- Check and add recruitmentSource column
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = 'recruitments' 
AND column_name = 'recruitmentSource';

SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE recruitments ADD COLUMN recruitmentSource varchar(100) DEFAULT NULL COMMENT "Recruitment source" AFTER email',
    'SELECT "recruitmentSource column already exists"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check and add recruitmentPipeline column
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = 'recruitments' 
AND column_name = 'recruitmentPipeline';

SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE recruitments ADD COLUMN recruitmentPipeline varchar(100) DEFAULT NULL COMMENT "Recruitment pipeline stage" AFTER recruitmentSource',
    'SELECT "recruitmentPipeline column already exists"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check and add platform column
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = 'recruitments' 
AND column_name = 'platform';

SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE recruitments ADD COLUMN platform varchar(100) DEFAULT NULL COMMENT "Platform/Department" AFTER recruitmentPipeline',
    'SELECT "platform column already exists"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Remove nationality column if it exists (as per requirements)
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = 'recruitments' 
AND column_name = 'nationality';

SET @sql = IF(@col_exists > 0, 
    'ALTER TABLE recruitments DROP COLUMN nationality',
    'SELECT "nationality column does not exist"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 6. CREATE INDEXES FOR BETTER PERFORMANCE
-- =====================================================

-- Indexes for roles table
CREATE INDEX IF NOT EXISTS idx_roles_active ON roles(isActive);
CREATE INDEX IF NOT EXISTS idx_roles_name ON roles(name);

-- Indexes for recruitment_sources table
CREATE INDEX IF NOT EXISTS idx_recruitment_sources_active ON recruitment_sources(isActive);
CREATE INDEX IF NOT EXISTS idx_recruitment_sources_name ON recruitment_sources(sourceName);

-- Indexes for recruitment_pipelines table
CREATE INDEX IF NOT EXISTS idx_recruitment_pipelines_active ON recruitment_pipelines(isActive);
CREATE INDEX IF NOT EXISTS idx_recruitment_pipelines_order ON recruitment_pipelines(stageOrder);
CREATE INDEX IF NOT EXISTS idx_recruitment_pipelines_name ON recruitment_pipelines(pipelineName);

-- Indexes for recruitment_platforms table
CREATE INDEX IF NOT EXISTS idx_recruitment_platforms_active ON recruitment_platforms(isActive);
CREATE INDEX IF NOT EXISTS idx_recruitment_platforms_name ON recruitment_platforms(platformName);

-- Indexes for recruitments table (for new columns)
CREATE INDEX IF NOT EXISTS idx_recruitments_source ON recruitments(recruitmentSource);
CREATE INDEX IF NOT EXISTS idx_recruitments_pipeline ON recruitments(recruitmentPipeline);
CREATE INDEX IF NOT EXISTS idx_recruitments_platform ON recruitments(platform);

-- =====================================================
-- 7. UPDATE USER ROLES (if users table exists)
-- =====================================================
-- Add role_id column to users table if it exists and doesn't have it

SET @table_exists = 0;
SELECT COUNT(*) INTO @table_exists 
FROM information_schema.tables 
WHERE table_schema = DATABASE() 
AND table_name = 'users';

SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = 'users' 
AND column_name = 'role_id';

SET @sql = IF(@table_exists > 0 AND @col_exists = 0, 
    'ALTER TABLE users ADD COLUMN role_id int(11) DEFAULT NULL COMMENT "Reference to roles table" AFTER email, ADD FOREIGN KEY (role_id) REFERENCES roles(id)',
    'SELECT "users table does not exist or role_id column already exists"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 8. DATA MIGRATION AND CLEANUP
-- =====================================================

-- Update existing recruitment records to use default values if needed
UPDATE recruitments 
SET recruitmentSource = 'Walk-In' 
WHERE recruitmentSource IS NULL OR recruitmentSource = '';

UPDATE recruitments 
SET recruitmentPipeline = 'Application Received' 
WHERE recruitmentPipeline IS NULL OR recruitmentPipeline = '';

UPDATE recruitments 
SET platform = 'National Stock Exchange' 
WHERE platform IS NULL OR platform = '';

-- =====================================================
-- 9. VERIFICATION QUERIES
-- =====================================================
-- Run these to verify the migration was successful:

-- Check roles table
SELECT 'Roles Table' as TableName, COUNT(*) as RecordCount FROM roles;

-- Check recruitment sources
SELECT 'Recruitment Sources' as TableName, COUNT(*) as RecordCount FROM recruitment_sources;

-- Check recruitment pipelines
SELECT 'Recruitment Pipelines' as TableName, COUNT(*) as RecordCount FROM recruitment_pipelines;

-- Check recruitment platforms
SELECT 'Recruitment Platforms' as TableName, COUNT(*) as RecordCount FROM recruitment_platforms;

-- Check recruitments table structure
SELECT 
    'Recruitments Table Columns' as Info,
    GROUP_CONCAT(COLUMN_NAME ORDER BY ORDINAL_POSITION) as Columns
FROM information_schema.columns 
WHERE table_schema = DATABASE() 
AND table_name = 'recruitments';

-- =====================================================
-- 10. SAMPLE DATA QUERIES
-- =====================================================
-- Sample queries to test the new functionality:

-- Get all active roles
-- SELECT * FROM roles WHERE isActive = 1 ORDER BY name;

-- Get all recruitment sources
-- SELECT * FROM recruitment_sources WHERE isActive = 1 ORDER BY sourceName;

-- Get recruitment pipeline in order
-- SELECT * FROM recruitment_pipelines WHERE isActive = 1 ORDER BY stageOrder;

-- Get all platforms
-- SELECT * FROM recruitment_platforms WHERE isActive = 1 ORDER BY platformName;

-- Get recruitment records with master data
-- SELECT 
--     r.*,
--     rs.sourceName as source_display_name,
--     rp.pipelineName as pipeline_display_name,
--     rpl.platformName as platform_display_name
-- FROM recruitments r
-- LEFT JOIN recruitment_sources rs ON r.recruitmentSource = rs.sourceName
-- LEFT JOIN recruitment_pipelines rp ON r.recruitmentPipeline = rp.pipelineName  
-- LEFT JOIN recruitment_platforms rpl ON r.platform = rpl.platformName
-- ORDER BY r.created_at DESC;

-- =====================================================
-- MIGRATION COMPLETE
-- =====================================================
-- This migration script has:
-- 1. Created roles master table with default data
-- 2. Created recruitment sources master table with default data
-- 3. Created recruitment pipelines master table with default data  
-- 4. Created recruitment platforms master table with default data
-- 5. Updated recruitments table structure (added new columns, removed nationality)
-- 6. Added performance indexes
-- 7. Updated users table to reference roles (if exists)
-- 8. Migrated existing data to use default values
-- 9. Provided verification and sample queries
-- =====================================================