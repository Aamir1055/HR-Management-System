-- Fix platform assignments to resolve 239 vs 342 employee count discrepancy
-- Run this script in MySQL Workbench or phpMyAdmin

-- BEFORE running this, make sure to backup your database!

-- Step 1: Check how many employees need platform assignment
SELECT 'BEFORE FIX: Employees without platform' as step,
       COUNT(*) as total_unassigned,
       SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as active_unassigned
FROM employees 
WHERE platform IS NULL OR TRIM(platform) = '' OR platform = '';

-- Step 2: Create 'All Platform' if it doesn't exist
INSERT INTO platforms (platform_name)
SELECT 'All Platform'
WHERE NOT EXISTS (
    SELECT 1 FROM platforms WHERE platform_name = 'All Platform'
);

-- Step 3: Verify 'All Platform' was created
SELECT 'All Platform created' as step, id, platform_name 
FROM platforms 
WHERE platform_name = 'All Platform';

-- Step 4: Update all employees without platform to 'All Platform'
UPDATE employees 
SET platform = 'All Platform'
WHERE platform IS NULL 
   OR TRIM(platform) = '' 
   OR platform = '';

-- Step 5: Verify the update worked
SELECT 'AFTER FIX: All Platform employees' as step,
       COUNT(*) as total_assigned,
       SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as active_assigned
FROM employees 
WHERE platform = 'All Platform';

-- Step 6: Check new platform distribution
SELECT 
    'Final Platform Distribution' as step,
    p.platform_name as platform,
    COUNT(e.id) as active_employee_count,
    SUM(e.monthlySalary) as total_salary
FROM platforms p
LEFT JOIN employees e ON p.platform_name = e.platform AND e.status = 1
GROUP BY p.id, p.platform_name
ORDER BY active_employee_count DESC;

-- Step 7: Final verification - these counts should now match
SELECT 'VERIFICATION' as step, 'Total Active Employees' as description, COUNT(*) as count
FROM employees WHERE status = 1
UNION ALL
SELECT 'VERIFICATION', 'Sum of Platform Counts', SUM(employee_count)
FROM (
    SELECT COUNT(e.id) as employee_count
    FROM platforms p
    LEFT JOIN employees e ON p.platform_name = e.platform AND e.status = 1
    GROUP BY p.id, p.platform_name
) as platform_totals;

-- Success message
SELECT 'SUCCESS!' as message, 
       'Your dashboard should now show the correct employee count' as result;
