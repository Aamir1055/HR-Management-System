-- SQL script to add missing columns to attendance table for duty hours calculation
-- This will enable the strict 100% threshold logic for half days

USE payroll_system2;

-- Add new columns to attendance table for duty hours tracking
ALTER TABLE attendance 
ADD COLUMN actual_hours_worked DECIMAL(4,2) DEFAULT 0.00 COMMENT 'Actual hours worked by employee',
ADD COLUMN late_minutes INT DEFAULT 0 COMMENT 'Minutes late from shift start time',
ADD COLUMN early_departure_minutes INT DEFAULT 0 COMMENT 'Minutes left early from shift end time',
ADD COLUMN attendance_status VARCHAR(50) DEFAULT 'FULL_DAY' COMMENT 'Attendance status (FULL_DAY, LATE_ARRIVAL, HALF_DAY, etc.)',
ADD COLUMN is_half_day TINYINT(1) DEFAULT 0 COMMENT '1 if marked as half day, 0 otherwise',
ADD COLUMN is_late TINYINT(1) DEFAULT 0 COMMENT '1 if marked as late, 0 otherwise',
ADD COLUMN duty_hours_deficit DECIMAL(4,2) DEFAULT 0.00 COMMENT 'Hours short of required duty hours',
ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last updated timestamp';

-- Add index for performance
ALTER TABLE attendance ADD INDEX idx_attendance_status (attendance_status);
ALTER TABLE attendance ADD INDEX idx_attendance_date (date);
ALTER TABLE attendance ADD INDEX idx_attendance_employee_date (employee_id, date);
