-- Add missing attendance columns to production database
-- These columns are needed for the enhanced payroll system

ALTER TABLE attendance 
ADD COLUMN actual_hours_worked DECIMAL(5,2) DEFAULT NULL COMMENT 'Total hours worked',
ADD COLUMN late_minutes INT DEFAULT 0 COMMENT 'Minutes late from shift start',
ADD COLUMN early_departure_minutes INT DEFAULT 0 COMMENT 'Minutes left early',
ADD COLUMN attendance_status VARCHAR(20) DEFAULT 'Present' COMMENT 'Present, Half Day, Absent, etc.',
ADD COLUMN is_half_day BOOLEAN DEFAULT FALSE COMMENT 'Whether this is a half day',
ADD COLUMN is_late BOOLEAN DEFAULT FALSE COMMENT 'Whether employee was late',
ADD COLUMN duty_hours_deficit DECIMAL(5,2) DEFAULT 0.00 COMMENT 'Hours short of required',
ADD COLUMN duty_hours DECIMAL(5,2) DEFAULT 8.00 COMMENT 'Required duty hours';

-- Confirm the changes
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'attendance' 
AND COLUMN_NAME IN ('actual_hours_worked', 'late_minutes', 'attendance_status', 'is_half_day', 'is_late');
