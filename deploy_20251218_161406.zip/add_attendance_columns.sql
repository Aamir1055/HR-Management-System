-- Add missing columns to attendance table for enhanced attendance tracking
-- This script adds columns needed for duty hours calculation and attendance status tracking

USE payroll_system2;

-- Add new columns to the attendance table
ALTER TABLE `attendance` 
ADD COLUMN `actual_hours_worked` DECIMAL(5,2) DEFAULT NULL COMMENT 'Total hours worked (punch_out - punch_in)',
ADD COLUMN `late_minutes` INT DEFAULT 0 COMMENT 'Minutes late from shift start time',
ADD COLUMN `early_departure_minutes` INT DEFAULT 0 COMMENT 'Minutes left early before shift end time',
ADD COLUMN `attendance_status` VARCHAR(20) DEFAULT 'Present' COMMENT 'Present, Half Day, Absent, etc.',
ADD COLUMN `is_half_day` BOOLEAN DEFAULT FALSE COMMENT 'Whether this day is marked as half day',
ADD COLUMN `is_late` BOOLEAN DEFAULT FALSE COMMENT 'Whether employee was late',
ADD COLUMN `duty_hours_deficit` DECIMAL(5,2) DEFAULT 0.00 COMMENT 'Hours short of required duty hours',
ADD COLUMN `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last update timestamp';

-- Add indexes for performance
CREATE INDEX `idx_attendance_date` ON `attendance` (`date`);
CREATE INDEX `idx_attendance_status` ON `attendance` (`attendance_status`);
CREATE INDEX `idx_attendance_employee_date` ON `attendance` (`employee_id`, `date`);
CREATE INDEX `idx_attendance_half_day` ON `attendance` (`is_half_day`);
CREATE INDEX `idx_attendance_late` ON `attendance` (`is_late`);

-- Add a comment to the table to describe the enhanced functionality
ALTER TABLE `attendance` COMMENT = 'Enhanced attendance table with duty hours tracking and strict half-day calculations';

COMMIT;
