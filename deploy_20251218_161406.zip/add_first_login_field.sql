-- Migration: Add first_login field to users table
-- This field tracks whether a user needs to complete their first login 2FA setup
-- Date: 2024-12-19

ALTER TABLE users ADD COLUMN first_login BOOLEAN DEFAULT TRUE;

-- Update existing users to not require first login setup (since they already exist)
UPDATE users SET first_login = FALSE WHERE created_at IS NOT NULL;

-- Add comment to document the field
ALTER TABLE users MODIFY COLUMN first_login BOOLEAN DEFAULT TRUE COMMENT 'Indicates if user needs to complete first login 2FA setup';
