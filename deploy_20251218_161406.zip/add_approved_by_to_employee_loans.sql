-- Migration: Add approved_by column to employee_loans table
-- Date: 2024-12-30
-- Description: Adds approved_by field to track loan approval information

USE payroll_management;

-- Add approved_by column to employee_loans table
ALTER TABLE employee_loans 
ADD COLUMN approved_by VARCHAR(255) NULL AFTER created_by,
ADD INDEX idx_approved_by (approved_by);

-- Update existing records to set approved_by to NULL (already default)
UPDATE employee_loans SET approved_by = NULL WHERE approved_by IS NULL;
