/**
 * Test Improved Import System
 * Verifies that the new flexible import system works correctly
 */

const mysql = require('mysql2/promise');
require('dotenv').config();

async function testImprovedImport() {
  const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'payroll_system2',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

  try {
    console.log('🧪 TESTING IMPROVED IMPORT SYSTEM');
    console.log('=================================');
    console.log('');

    // Test 1: Check if new services exist
    console.log('📁 Checking if improved services exist...');
    const fs = require('fs');
    const path = require('path');
    
    const requiredFiles = [
      'services/FlexibleEmployeeValidationService.js',
      'services/AutoCreationService.js', 
      'services/ImprovedEmployeeImportService.js'
    ];

    let allFilesExist = true;
    requiredFiles.forEach(file => {
      const filePath = path.join(__dirname, file);
      if (fs.existsSync(filePath)) {
        console.log(`   ✅ ${file}`);
      } else {
        console.log(`   ❌ ${file} - MISSING!`);
        allFilesExist = false;
      }
    });

    if (!allFilesExist) {
      console.log('\n❌ Some required files are missing. Run improve_import_validation.js first.');
      return;
    }

    // Test 2: Check database improvements
    console.log('\n🗄️ Checking database improvements...');
    
    const [officeCount] = await pool.query('SELECT COUNT(*) as count FROM offices');
    const [positionCount] = await pool.query('SELECT COUNT(*) as count FROM positions');
    
    console.log(`   📊 Offices available: ${officeCount[0].count}`);
    console.log(`   📊 Positions available: ${positionCount[0].count}`);

    if (officeCount[0].count < 10) {
      console.log('   ⚠️ Low office count. Consider running sync_db_with_excel.js');
    }

    if (positionCount[0].count < 20) {
      console.log('   ⚠️ Low position count. Consider running sync_db_with_excel.js');
    }

    // Test 3: Test auto-creation service
    console.log('\n🏗️ Testing auto-creation service...');
    
    try {
      const AutoCreationService = require('./services/AutoCreationService');
      const autoCreation = new AutoCreationService(pool);
      
      // Test office creation
      const testOfficeId = await autoCreation.getOrCreateOffice('Test Office for Import');
      console.log(`   ✅ Auto-created office with ID: ${testOfficeId}`);
      
      // Test position creation
      const testPositionId = await autoCreation.getOrCreatePosition('Test Position for Import');
      console.log(`   ✅ Auto-created position with ID: ${testPositionId}`);
      
    } catch (error) {
      console.log(`   ❌ Auto-creation test failed: ${error.message}`);
    }

    // Test 4: Test flexible validation
    console.log('\n🔍 Testing flexible validation...');
    
    try {
      const FlexibleEmployeeValidationService = require('./services/FlexibleEmployeeValidationService');
      const flexValidation = new FlexibleEmployeeValidationService();
      
      // Test with minimal data
      const testEmployeeData = {
        employeeId: 'TEST001',
        email: 'test@example.com',
        first_name: 'Test',
        last_name: 'Employee'
      };
      
      const validation = flexValidation.validateForImport(testEmployeeData, 0);
      
      if (validation.isValid) {
        console.log('   ✅ Flexible validation works - accepts minimal data');
        console.log(`   📝 Generated ${validation.warnings.length} warnings`);
      } else {
        console.log('   ❌ Flexible validation failed');
        console.log('   Errors:', validation.errors);
      }
      
    } catch (error) {
      console.log(`   ❌ Flexible validation test failed: ${error.message}`);
    }

    // Test 5: Check employee table flexibility
    console.log('\n📋 Checking employee table flexibility...');
    
    try {
      const [tableInfo] = await pool.query('DESCRIBE employees');
      const nullableFields = tableInfo.filter(col => col.Null === 'YES').map(col => col.Field);
      
      console.log(`   📊 Nullable fields: ${nullableFields.length}`);
      
      const importantNullableFields = ['nationality', 'phone', 'whatsapp', 'gender', 'marital_status'];
      const flexibleFields = importantNullableFields.filter(field => nullableFields.includes(field));
      
      console.log(`   ✅ Flexible fields: ${flexibleFields.join(', ')}`);
      
      if (flexibleFields.length >= 3) {
        console.log('   ✅ Employee table is sufficiently flexible for imports');
      } else {
        console.log('   ⚠️ Employee table could be more flexible. Run sync_db_with_excel.js');
      }
      
    } catch (error) {
      console.log(`   ❌ Table flexibility check failed: ${error.message}`);
    }

    console.log('\n📊 IMPORT IMPROVEMENT SUMMARY');
    console.log('============================');
    console.log('✅ Database has been enhanced for better Excel compatibility');
    console.log('✅ Flexible validation services are available');
    console.log('✅ Auto-creation services will handle missing offices/positions');
    console.log('✅ Import process is now more forgiving and informative');
    console.log('');
    console.log('💡 NEXT STEPS:');
    console.log('1. Try uploading your 363-record Excel file again');
    console.log('2. The system should now import significantly more records');
    console.log('3. Check the response for detailed warnings about any issues');
    console.log('4. Missing offices and positions will be auto-created');

  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await pool.end();
  }
}

testImprovedImport();