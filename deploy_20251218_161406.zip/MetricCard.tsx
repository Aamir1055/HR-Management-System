import React, { ReactNode } from 'react';
import { LucideIcon, User, Building } from 'lucide-react';

export interface MetricCardProps {
  title: string;
  value: string | number | ReactNode;
  icon?: LucideIcon;
  color: 'blue' | 'yellow' | 'red' | 'purple' | 'green';
  trend?: {
    value: number;
    isPositive: boolean;
  };
  onClick?: () => void;
}

const colorClasses: Record<MetricCardProps['color'], string> = {
  blue: 'bg-blue-50 text-blue-600',
  green: 'bg-green-50 text-green-600',
  yellow: 'bg-yellow-50 text-yellow-600',
  red: 'bg-red-50 text-red-600',
  purple: 'bg-purple-50 text-purple-600',
};

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  icon: Icon = User,
  color,
  trend,
  onClick,
}) => {
  return (
    <div 
      className={`bg-white rounded-lg shadow-md border border-gray-200 p-6 transform transition duration-300 hover:scale-105 hover:shadow-lg ${
        onClick ? 'cursor-pointer hover:border-blue-300 active:scale-95' : ''
      }`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <div className="text-2xl font-bold text-gray-900 mt-2">{value}</div>

          {trend && (
            <p
              className={`text-sm mt-2 ${
                trend.isPositive ? 'text-green-600' : 'text-red-600'
              }`}
            >
              {trend.isPositive ? '↗' : '↘'} {Math.abs(trend.value)}% from last month
            </p>
          )}
        </div>

        <div className={`p-3 rounded-full ${colorClasses[color]} flex items-center justify-center`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
};

