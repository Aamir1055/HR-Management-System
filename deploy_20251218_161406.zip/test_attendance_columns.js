/**
 * Test Attendance Column Mapping
 * Verifies that "Employee ID" (with space) is properly recognized
 */

console.log('🧪 TESTING ATTENDANCE COLUMN MAPPING');
console.log('====================================');
console.log('');

// Simulate your Excel data
const excelRow = {
  'Employee ID': '67',  // With space - YOUR FORMAT
  'Name': 'Sayed Shah',
  'Date': '2025-10-01',
  'Punch In': '09:27:49',
  'Punch Out': '18:32:10'
};

console.log('📋 Your Excel Format:');
console.log('   Columns:', Object.keys(excelRow));
console.log('');

// Test column mapping logic
const columnMapping = {
  employeeId: null,
  date: null,
  punchIn: null,
  punchOut: null
};

const employeeIdVariations = ['EmployeeID', 'Employee ID', 'employee_id', 'employeeId', 'Emp ID', 'EmpID'];
const dateVariations = ['Date', 'date', 'DATE', 'Attendance Date'];
const punchInVariations = ['Punch In', 'PunchIn', 'punch_in', 'punchIn', 'Check In', 'CheckIn', 'Time In'];
const punchOutVariations = ['Punch Out', 'PunchOut', 'punch_out', 'punchOut', 'Check Out', 'CheckOut', 'Time Out'];

columnMapping.employeeId = employeeIdVariations.find(col => col in excelRow);
columnMapping.date = dateVariations.find(col => col in excelRow);
columnMapping.punchIn = punchInVariations.find(col => col in excelRow);
columnMapping.punchOut = punchOutVariations.find(col => col in excelRow);

console.log('🔍 Column Mapping Results:');
console.log(`   Employee ID: "${columnMapping.employeeId}" ${columnMapping.employeeId ? '✅' : '❌'}`);
console.log(`   Date: "${columnMapping.date}" ${columnMapping.date ? '✅' : '❌'}`);
console.log(`   Punch In: "${columnMapping.punchIn}" ${columnMapping.punchIn ? '✅' : '❌'}`);
console.log(`   Punch Out: "${columnMapping.punchOut}" ${columnMapping.punchOut ? '✅' : '❌'}`);
console.log('');

// Test data extraction
if (columnMapping.employeeId && columnMapping.date && columnMapping.punchIn && columnMapping.punchOut) {
  const employeeId = excelRow[columnMapping.employeeId];
  const date = excelRow[columnMapping.date];
  const punchIn = excelRow[columnMapping.punchIn];
  const punchOut = excelRow[columnMapping.punchOut];

  console.log('📊 Extracted Data:');
  console.log(`   Employee ID: ${employeeId}`);
  console.log(`   Date: ${date}`);
  console.log(`   Punch In: ${punchIn}`);
  console.log(`   Punch Out: ${punchOut}`);
  console.log('');

  console.log('✅ SUCCESS!');
  console.log('===========');
  console.log('Your attendance Excel format is now supported!');
  console.log('');
  console.log('🔄 IMPORTANT: Restart your backend server!');
  console.log('   1. Stop the backend (Ctrl+C)');
  console.log('   2. Run: npm start');
  console.log('   3. Try uploading your attendance Excel again');
} else {
  console.log('❌ FAILED!');
  console.log('Some columns could not be mapped.');
}

console.log('');
console.log('💡 Supported Column Names:');
console.log('   Employee ID: "Employee ID", "EmployeeID", "employee_id", "Emp ID"');
console.log('   Date: "Date", "date", "Attendance Date"');
console.log('   Punch In: "Punch In", "PunchIn", "Check In", "Time In"');
console.log('   Punch Out: "Punch Out", "PunchOut", "Check Out", "Time Out"');