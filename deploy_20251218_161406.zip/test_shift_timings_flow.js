/**
 * Test Shift Timings Flow
 * Simulates the complete import flow to trace shift timings
 */

const { processExcelRow, processDateFields } = require('./utils/excelUtils');
const { EmployeeFieldMappings } = require('./models/Employee');

console.log('🧪 TESTING SHIFT TIMINGS IMPORT FLOW');
console.log('====================================');
console.log('');

// Simulate an Excel row with shift timings
const excelRow = {
  'Employee ID': '12345',
  'First Name': 'John',
  'Last Name': 'Doe',
  'Email': 'john.doe@example.com',
  'Office': 'M09 - Amari Capital Consultancy',
  'Position': 'Tele Sales Assistant',
  'Salary': 5000,
  'Shift Timings': '09:00-18:00',  // THIS IS THE KEY FIELD
  'Joining Date': '2024-01-01',
  'Status': 'active'
};

console.log('1️⃣ Original Excel Row:');
console.log(`   Shift Timings: "${excelRow['Shift Timings']}"`);
console.log('');

// Step 1: Check column mapping
console.log('2️⃣ Checking Column Mapping:');
const shiftTimingsMapping = EmployeeFieldMappings.excelToModel['Shift Timings'];
console.log(`   "Shift Timings" maps to: "${shiftTimingsMapping}"`);

if (!shiftTimingsMapping) {
  console.log('   ❌ ERROR: "Shift Timings" is not mapped!');
  console.log('   This is why shift timings are not being imported.');
} else {
  console.log('   ✅ Mapping exists');
}
console.log('');

// Step 2: Process Excel row (simulate)
console.log('3️⃣ After processExcelRow:');
const columnMapping = {
  'Employee ID': 'employeeId',
  'First Name': 'first_name',
  'Last Name': 'last_name',
  'Email': 'email',
  'Office': 'office_name',
  'Position': 'position_name',
  'Salary': 'monthlySalary',
  'Shift Timings': 'shift_timings',
  'Joining Date': 'joiningDate',
  'Status': 'status'
};

const processedRow = {};
Object.keys(excelRow).forEach(key => {
  const mappedKey = columnMapping[key];
  if (mappedKey) {
    processedRow[mappedKey] = excelRow[key];
  }
});

console.log(`   shift_timings: "${processedRow.shift_timings}"`);
console.log('');

// Step 3: After date processing
console.log('4️⃣ After processDateFields:');
const withDates = { ...processedRow };
console.log(`   shift_timings: "${withDates.shift_timings}"`);
console.log('');

// Step 4: After convertExcelRowToEmployee
console.log('5️⃣ After convertExcelRowToEmployee:');
const employeeData = {
  employeeId: withDates.employeeId,
  name: `${withDates.first_name} ${withDates.last_name}`,
  first_name: withDates.first_name,
  last_name: withDates.last_name,
  email: withDates.email,
  office_id: 1, // Would be resolved
  position_id: 1, // Would be resolved
  monthlySalary: withDates.monthlySalary,
  joiningDate: withDates.joiningDate,
  status: 1,
  shift_timings: withDates.shift_timings || null  // KEY LINE
};

console.log(`   shift_timings: "${employeeData.shift_timings}"`);
console.log('');

// Step 5: After formatEmployeeForInsert
console.log('6️⃣ After formatEmployeeForInsert:');
const formattedArray = [
  employeeData.employeeId,
  employeeData.name,
  employeeData.first_name,
  employeeData.last_name,
  null, // nationality
  employeeData.email,
  employeeData.office_id,
  employeeData.position_id,
  employeeData.monthlySalary,
  employeeData.joiningDate,
  employeeData.status,
  null, // dob
  null, // passport_number
  null, // passport_expiry
  null, // visa_type
  null, // visa_expiry
  null, // platform
  null, // address
  null, // current_address
  null, // phone
  null, // whatsapp
  null, // gender
  null, // primary_language
  null, // secondary_language
  null, // marital_status
  null, // hiring_source
  'AED', // salary_currency
  null, // emirates_id
  null, // emergency_contact
  null, // emergency_contact_relation
  employeeData.shift_timings  // INDEX 30 - KEY POSITION
];

console.log(`   Array index 30 (shift_timings): "${formattedArray[30]}"`);
console.log('');

console.log('📊 FLOW ANALYSIS');
console.log('================');
if (formattedArray[30] === '09:00-18:00') {
  console.log('✅ Shift timings flows correctly through the entire process!');
  console.log('');
  console.log('If imports are still not working, check:');
  console.log('1. Is the backend server restarted after code changes?');
  console.log('2. Is the Excel file using the exact column name "Shift Timings"?');
  console.log('3. Are there any errors in the backend console during import?');
} else {
  console.log('❌ Shift timings is lost somewhere in the process!');
  console.log(`Expected: "09:00-18:00"`);
  console.log(`Got: "${formattedArray[30]}"`);
}