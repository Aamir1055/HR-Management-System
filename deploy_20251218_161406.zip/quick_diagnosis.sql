-- Quick diagnosis of platform assignment issue
-- Run these queries in MySQL Workbench or phpMyAdmin

-- 1. Total employee count
SELECT 'Total Employees' as description, COUNT(*) as count FROM employees;

-- 2. Active employees only
SELECT 'Active Employees' as description, COUNT(*) as count FROM employees WHERE status = 1;

-- 3. Platform assignment breakdown
SELECT 
    CASE 
        WHEN platform IS NULL THEN 'NULL Platform'
        WHEN TRIM(platform) = '' THEN 'Empty Platform'
        WHEN platform = '' THEN 'Empty String Platform'
        ELSE 'Has Platform'
    END as platform_status,
    COUNT(*) as total_employees,
    SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as active_employees
FROM employees 
GROUP BY platform_status
ORDER BY total_employees DESC;

-- 4. Current platform distribution (what your dashboard shows)
SELECT 
    p.platform_name as platform,
    COUNT(e.id) as employee_count
FROM platforms p
LEFT JOIN employees e ON p.platform_name = e.platform AND e.status = 1
GROUP BY p.id, p.platform_name
ORDER BY employee_count DESC;

-- 5. List of platforms in master table
SELECT 'Available Platforms:' as info, platform_name FROM platforms ORDER BY platform_name;

-- 6. Sample of employees without platform (first 10)
SELECT 
    employeeId,
    name,
    platform,
    status
FROM employees 
WHERE (platform IS NULL OR TRIM(platform) = '' OR platform = '') 
  AND status = 1
LIMIT 10;
