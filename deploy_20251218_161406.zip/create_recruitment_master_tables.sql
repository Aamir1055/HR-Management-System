-- Create Recruitment Master Tables
-- This script creates master tables for Recruitment Source, Pipeline, and Platform

-- =====================================================
-- 1. RECRUITMENT SOURCES MASTER TABLE
-- =====================================================
CREATE TABLE `recruitment_sources` (
  `sourceId` int(11) NOT NULL AUTO_INCREMENT,
  `sourceName` varchar(100) NOT NULL COMMENT 'Recruitment source name',
  `description` text DEFAULT NULL COMMENT 'Optional description',
  `isActive` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Active status',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record update timestamp',
  PRIMARY KEY (`sourceId`),
  UNIQUE KEY `unique_source_name` (`sourceName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Recruitment sources master data';

-- Insert default recruitment sources
INSERT INTO `recruitment_sources` (`sourceName`, `description`) VALUES
('Indeed', 'Job applications from Indeed job portal'),
('Candidate Reference', 'Applications through candidate referrals'),
('Employee Reference', 'Applications through employee referrals'),
('Walk-In', 'Direct walk-in applications');

-- =====================================================
-- 2. RECRUITMENT PIPELINES MASTER TABLE
-- =====================================================
CREATE TABLE `recruitment_pipelines` (
  `pipelineId` int(11) NOT NULL AUTO_INCREMENT,
  `pipelineName` varchar(100) NOT NULL COMMENT 'Pipeline stage name',
  `description` text DEFAULT NULL COMMENT 'Optional description',
  `stageOrder` int(11) NOT NULL DEFAULT 0 COMMENT 'Order of stage in pipeline',
  `isActive` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Active status',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record update timestamp',
  PRIMARY KEY (`pipelineId`),
  UNIQUE KEY `unique_pipeline_name` (`pipelineName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Recruitment pipeline stages master data';

-- Insert default recruitment pipeline stages
INSERT INTO `recruitment_pipelines` (`pipelineName`, `description`, `stageOrder`) VALUES
('HR Screening', 'Initial HR screening stage', 1),
('Screening Reject', 'Rejected at screening stage', 2),
('R1', 'First round of interviews', 3),
('R1 Reject', 'Rejected after first round', 4),
('R2', 'Second round of interviews', 5),
('R2 Reject', 'Rejected after second round', 6),
('Offered', 'Job offer extended to candidate', 7),
('Onboarded', 'Candidate successfully onboarded', 8);

-- =====================================================
-- 3. RECRUITMENT PLATFORMS MASTER TABLE
-- =====================================================
CREATE TABLE `recruitment_platforms` (
  `platformId` int(11) NOT NULL AUTO_INCREMENT,
  `platformName` varchar(100) NOT NULL COMMENT 'Platform name',
  `description` text DEFAULT NULL COMMENT 'Optional description',
  `isActive` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Active status',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record update timestamp',
  PRIMARY KEY (`platformId`),
  UNIQUE KEY `unique_platform_name` (`platformName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Recruitment platforms master data';

-- Insert default recruitment platforms
INSERT INTO `recruitment_platforms` (`platformName`, `description`) VALUES
('National Stock Exchange', 'National Stock Exchange trading platform'),
('Forex', 'Foreign exchange trading platform');

-- =====================================================
-- 4. UPDATE EXISTING RECRUITMENTS TABLE (if needed)
-- =====================================================
-- Note: The recruitments table should already have these columns:
-- - recruitmentSource varchar(100)
-- - recruitmentPipeline varchar(100) 
-- - platform varchar(100)
-- 
-- If any are missing, uncomment and run the appropriate ALTER statements:

-- ALTER TABLE recruitments 
-- ADD COLUMN recruitmentSource varchar(100) DEFAULT NULL COMMENT 'Recruitment source' 
-- AFTER email;

-- ALTER TABLE recruitments 
-- ADD COLUMN recruitmentPipeline varchar(100) DEFAULT NULL COMMENT 'Recruitment pipeline stage' 
-- AFTER recruitmentSource;

-- ALTER TABLE recruitments 
-- ADD COLUMN platform varchar(100) DEFAULT NULL COMMENT 'Platform/Department' 
-- AFTER recruitmentPipeline;

-- =====================================================
-- 5. CREATE INDEXES FOR BETTER PERFORMANCE
-- =====================================================
CREATE INDEX idx_recruitment_sources_active ON recruitment_sources(isActive);
CREATE INDEX idx_recruitment_pipelines_active ON recruitment_pipelines(isActive);
CREATE INDEX idx_recruitment_pipelines_order ON recruitment_pipelines(stageOrder);
CREATE INDEX idx_recruitment_platforms_active ON recruitment_platforms(isActive);

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================
-- Run these to verify the tables were created successfully:
-- SELECT COUNT(*) as sources_count FROM recruitment_sources;
-- SELECT COUNT(*) as pipelines_count FROM recruitment_pipelines;
-- SELECT COUNT(*) as platforms_count FROM recruitment_platforms;