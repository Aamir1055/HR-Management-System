-- Create 'All Platform' and assign to unassigned employees
-- This will fix the 239 vs 342 employee count discrepancy

-- Step 1: Check if 'All Platform' already exists
SELECT 'Checking existing platforms' as action, 
       id, 
       platform_name 
FROM platforms 
WHERE platform_name = 'All Platform';

-- Step 2: Insert 'All Platform' if it doesn't exist
INSERT INTO platforms (platform_name)
SELECT 'All Platform'
WHERE NOT EXISTS (
    SELECT 1 FROM platforms WHERE platform_name = 'All Platform'
);

-- Step 3: Verify 'All Platform' was created/exists
SELECT 'All Platform created/verified' as action,
       id,
       platform_name
FROM platforms 
WHERE platform_name = 'All Platform';

-- Step 4: Count employees without platform assignment (before fix)
SELECT 'Before Fix - Unassigned Employees' as status,
       COUNT(*) as count,
       SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as active_count
FROM employees 
WHERE platform IS NULL 
   OR TRIM(platform) = ''
   OR platform = '';

-- Step 5: Update employees without platform to 'All Platform'
UPDATE employees 
SET platform = 'All Platform'
WHERE platform IS NULL 
   OR TRIM(platform) = ''
   OR platform = '';

-- Step 6: Show the results after assignment
SELECT 'After Fix - All Platform Employees' as status,
       COUNT(*) as total_employees,
       SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as active_employees
FROM employees 
WHERE platform = 'All Platform';

-- Step 7: Verify new platform summary totals
SELECT 'New Platform Summary' as report_type,
       p.platform_name as platform,
       COUNT(e.id) as employee_count,
       SUM(e.monthlySalary) as total_salary
FROM platforms p
LEFT JOIN employees e ON p.platform_name = e.platform AND e.status = 1
GROUP BY p.id, p.platform_name
ORDER BY employee_count DESC;

-- Step 8: Verify total count now matches
SELECT 'Total Verification' as check_type,
       'All Active Employees' as description,
       COUNT(*) as count
FROM employees 
WHERE status = 1
UNION ALL
SELECT 'Total Verification' as check_type,
       'Platform Summary Total' as description,
       SUM(employee_count) as count
FROM (
    SELECT COUNT(e.id) as employee_count
    FROM platforms p
    LEFT JOIN employees e ON p.platform_name = e.platform AND e.status = 1
    GROUP BY p.id, p.platform_name
) as platform_counts;

-- Step 9: Sample of employees now assigned to 'All Platform'
SELECT 'All Platform Employees Sample' as info,
       employeeId,
       name,
       email,
       platform,
       status,
       joiningDate
FROM employees 
WHERE platform = 'All Platform'
ORDER BY joiningDate DESC
LIMIT 10;
