-- Migration: Add Platform column to recruitments table
-- Run this SQL command on your server database

ALTER TABLE recruitments 
ADD COLUMN platform varchar(100) DEFAULT NULL COMMENT 'Trading platform (National Stock Exchange, Forex)' 
AFTER recruitmentPipeline;

-- Verify the column was added
DESCRIBE recruitments;