// MySQL database connection pool configuration for PayRoll Management System
// Provides optimized connection pooling with environment-based configuration for scalable database access
const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  rowsAsArray: false  
});

module.exports = pool;
