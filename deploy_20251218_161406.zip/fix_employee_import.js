/**
 * Master Employee Import Fix Script
 * 
 * This script orchestrates the complete process of diagnosing and fixing
 * employee Excel import issues. It runs all validation and cleanup scripts
 * in the correct order and provides step-by-step guidance.
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

/**
 * Run a Node.js script with arguments
 * @param {string} scriptPath - Path to the script
 * @param {string[]} args - Arguments to pass
 * @returns {Promise} - Promise that resolves when script completes
 */
function runScript(scriptPath, args = []) {
    return new Promise((resolve, reject) => {
        console.log(`\n🔧 Running: node ${scriptPath} ${args.join(' ')}`);
        
        const child = spawn('node', [scriptPath, ...args], {
            stdio: 'inherit',
            shell: true
        });

        child.on('close', (code) => {
            if (code === 0) {
                resolve();
            } else {
                reject(new Error(`Script ${scriptPath} exited with code ${code}`));
            }
        });

        child.on('error', (error) => {
            reject(error);
        });
    });
}

/**
 * Check if a file exists
 * @param {string} filePath - Path to check
 * @returns {boolean} - True if file exists
 */
function fileExists(filePath) {
    return fs.existsSync(filePath);
}

/**
 * Main orchestration function
 */
async function main() {
    const args = process.argv.slice(2);
    
    if (args.length === 0) {
        console.log('='.repeat(80));
        console.log('🚀 EMPLOYEE IMPORT ISSUE DIAGNOSTIC AND FIX TOOL');
        console.log('='.repeat(80));
        console.log('');
        console.log('This script will help you diagnose and fix issues with Excel employee imports.');
        console.log('It runs multiple validation scripts in sequence to identify and fix common problems.');
        console.log('');
        console.log('Usage: node fix_employee_import.js <excel_file_path> [options]');
        console.log('');
        console.log('Options:');
        console.log('  --auto-fix     Automatically apply all possible fixes');
        console.log('  --report-only  Only generate reports, no fixes');
        console.log('');
        console.log('Examples:');
        console.log('  node fix_employee_import.js employees.xlsx');
        console.log('  node fix_employee_import.js employees.xlsx --auto-fix');
        console.log('  node fix_employee_import.js employees.xlsx --report-only');
        console.log('');
        console.log('What this tool does:');
        console.log('  1. 🏢 Creates missing offices and positions from your Excel file');
        console.log('  2. ✅ Comprehensive validation (emails, dates, duplicates, required fields)');
        console.log('  3. 📧 Email validation and auto-fixing');
        console.log('  4. 🔄 Duplicate detection and removal');
        console.log('  5. 📊 Detailed reporting with specific row numbers');
        console.log('  6. 💡 Step-by-step guidance for manual fixes');
        return;
    }

    const filePath = args[0];
    const autoFix = args.includes('--auto-fix');
    const reportOnly = args.includes('--report-only');

    // Validate input file
    if (!fileExists(filePath)) {
        console.error(`❌ Error: File not found: ${filePath}`);
        process.exit(1);
    }

    try {
        console.log('='.repeat(80));
        console.log('🚀 STARTING EMPLOYEE IMPORT DIAGNOSTIC');
        console.log('='.repeat(80));
        console.log(`📁 File: ${filePath}`);
        console.log(`🔧 Mode: ${autoFix ? 'Auto-fix' : reportOnly ? 'Report-only' : 'Interactive'}`);

        // Step 1: Create missing offices and positions
        console.log('\n🏢 STEP 1: CREATE MISSING OFFICES AND POSITIONS');
        console.log('-'.repeat(50));
        await runScript('create_missing_offices.js', [filePath]);

        // Step 2: Comprehensive validation
        console.log('\n📋 STEP 2: COMPREHENSIVE VALIDATION');
        console.log('-'.repeat(50));
        await runScript('comprehensive_validation.js', [filePath, '--report']);

        if (reportOnly) {
            console.log('\n✅ REPORT-ONLY MODE COMPLETE');
            console.log('Check the generated validation report files for detailed analysis.');
            return;
        }

        // Step 3: Email validation and fixing
        console.log('\n📧 STEP 3: EMAIL VALIDATION AND FIXING');
        console.log('-'.repeat(50));
        if (autoFix) {
            await runScript('validate_and_fix_emails.js', [filePath, '--fix']);
        } else {
            await runScript('validate_and_fix_emails.js', [filePath]);
            console.log('\n💡 To apply email fixes, run:');
            console.log(`   node validate_and_fix_emails.js "${filePath}" --fix`);
        }

        // Step 4: Duplicate detection and handling
        console.log('\n🔄 STEP 4: DUPLICATE DETECTION');
        console.log('-'.repeat(50));
        if (autoFix) {
            await runScript('detect_duplicates.js', [filePath, '--remove']);
        } else {
            await runScript('detect_duplicates.js', [filePath]);
            console.log('\n💡 To remove duplicates, run:');
            console.log(`   node detect_duplicates.js "${filePath}" --remove`);
            console.log('💡 To mark duplicates for review, run:');
            console.log(`   node detect_duplicates.js "${filePath}" --mark`);
        }

        // Final recommendations
        console.log('\n' + '='.repeat(80));
        console.log('✅ DIAGNOSTIC COMPLETE - NEXT STEPS');
        console.log('='.repeat(80));

        if (autoFix) {
            console.log('\n🔧 AUTO-FIXES APPLIED:');
            console.log('   ✅ Email formats corrected (where possible)');
            console.log('   ✅ Duplicate rows removed');
            console.log('   ✅ Cleaned files created with "_cleaned" suffix');
            console.log('');
            console.log('📝 MANUAL REVIEW NEEDED:');
            console.log('   1. Check the cleaned files for accuracy');
            console.log('   2. Fix remaining validation errors manually');
            console.log('   3. Ensure all dates are in DD/MM/YYYY format');
            console.log('   4. Verify office and position names match your database');
            console.log('   5. Import the cleaned file to your system');
        } else {
            console.log('\n📋 RECOMMENDED ACTIONS:');
            console.log('   1. Review all validation reports generated');
            console.log('   2. Fix critical errors (missing fields, invalid emails)');
            console.log('   3. Run this script with --auto-fix to apply automatic corrections');
            console.log('   4. Manually fix any remaining issues');
            console.log('   5. Re-run validation until all issues are resolved');
        }

        console.log('\n🎯 KEY POINTS FOR SUCCESSFUL IMPORT:');
        console.log('   • All Employee IDs must be unique');
        console.log('   • All email addresses must be valid and unique');
        console.log('   • Dates should be in DD/MM/YYYY format consistently');
        console.log('   • Office and Position names must exactly match database values');
        console.log('   • Status must be "active" or "inactive"');
        console.log('   • Salaries must be positive numbers');

        console.log('\n📞 IF YOU STILL HAVE IMPORT ISSUES:');
        console.log('   • Check your database for foreign key constraints');
        console.log('   • Verify unique constraints on email and employee ID fields');
        console.log('   • Consider importing in smaller batches to isolate problematic rows');
        console.log('   • Review import service logs for specific error messages');

    } catch (error) {
        console.error(`\n❌ Error during process: ${error.message}`);
        process.exit(1);
    }
}

// Run the script
if (require.main === module) {
    main().catch(error => {
        console.error('Fatal error:', error.message);
        process.exit(1);
    });
}

module.exports = {
    runScript,
    fileExists
};
