-- Half Day Waivers Table
-- This table tracks half day waivers granted by administrators as tokens of grace

CREATE TABLE IF NOT EXISTS half_day_waivers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT(11) NOT NULL,
    date DATE NOT NULL,
    waived_by VARCHAR(100) NOT NULL,
    reason VARCHAR(255) DEFAULT 'Administrative grace',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Ensure one waiver per employee per date
    UNIQUE KEY unique_employee_date (employee_id, date),
    
    -- Foreign key constraints
    FOREIGN KEY (employee_id) REFERENCES employees(employeeId) ON DELETE CASCADE,
    
    -- Index for faster lookups
    INDEX idx_employee_date (employee_id, date),
    INDEX idx_date (date),
    INDEX idx_waived_by (waived_by)
) COMMENT = 'Tracks half day waivers granted by administrators as tokens of grace';
