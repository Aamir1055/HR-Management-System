-- ===============================================
-- ADD DUTY HOURS TRACKING TO ATTENDANCE TABLE
-- ===============================================
-- This migration adds columns to track calculated duty hours, 
-- late arrivals, half days, and attendance status automatically

-- Check if columns already exist before adding them
SET @column_exists = 0;
SELECT COUNT(*) INTO @column_exists 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
  AND TABLE_NAME = 'attendance' 
  AND COLUMN_NAME = 'actual_hours_worked';

-- Add new columns for duty hours tracking if they don't exist
SET @sql = CASE 
  WHEN @column_exists = 0 THEN 
    'ALTER TABLE attendance 
     ADD COLUMN actual_hours_worked DECIMAL(4,2) DEFAULT 0.00 COMMENT "Actual hours worked calculated from punch times",
     ADD COLUMN late_minutes INT DEFAULT 0 COMMENT "Minutes late from scheduled start time",
     ADD COLUMN early_departure_minutes INT DEFAULT 0 COMMENT "Minutes early from scheduled end time", 
     ADD COLUMN attendance_status VARCHAR(20) DEFAULT "UNKNOWN" COMMENT "Calculated attendance status",
     ADD COLUMN is_half_day BOOLEAN DEFAULT FALSE COMMENT "Flag indicating if this is a half day",
     ADD COLUMN is_late BOOLEAN DEFAULT FALSE COMMENT "Flag indicating if employee was late",
     ADD COLUMN duty_hours_deficit DECIMAL(4,2) DEFAULT 0.00 COMMENT "Shortage in required duty hours",
     ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT "Last update timestamp";'
  ELSE 
    'SELECT "Duty hours columns already exist" as message;'
END;

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ===============================================
-- ADD INDEXES FOR PERFORMANCE
-- ===============================================

-- Index for attendance status queries
CREATE INDEX IF NOT EXISTS idx_attendance_status 
ON attendance (attendance_status);

-- Index for half day queries
CREATE INDEX IF NOT EXISTS idx_is_half_day 
ON attendance (is_half_day);

-- Index for late arrival queries  
CREATE INDEX IF NOT EXISTS idx_is_late 
ON attendance (is_late);

-- Composite index for payroll calculations
CREATE INDEX IF NOT EXISTS idx_employee_date_status 
ON attendance (employee_id, date, attendance_status);

-- ===============================================
-- UPDATE EXISTING RECORDS (SAMPLE)
-- ===============================================
-- This section shows how to update existing records
-- Run the actual updates using the dutyHoursService

-- Example: Mark obvious absent records
UPDATE attendance 
SET attendance_status = 'ABSENT',
    is_half_day = TRUE,
    actual_hours_worked = 0.00
WHERE (punch_in IS NULL OR punch_in = '00:00:00' OR punch_in = '00:00')
  AND (punch_out IS NULL OR punch_out = '00:00:00' OR punch_out = '00:00')
  AND attendance_status = 'UNKNOWN';

-- ===============================================
-- VERIFICATION QUERIES
-- ===============================================

-- Check the new structure
DESCRIBE attendance;

-- Count records by attendance status
SELECT 
    attendance_status,
    COUNT(*) as count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM attendance), 2) as percentage
FROM attendance 
GROUP BY attendance_status
ORDER BY count DESC;

-- Sample of updated records
SELECT 
    employee_id,
    date,
    punch_in,
    punch_out,
    actual_hours_worked,
    late_minutes,
    attendance_status,
    is_half_day,
    is_late
FROM attendance 
WHERE attendance_status != 'UNKNOWN'
LIMIT 20;

-- Summary statistics
SELECT 
    COUNT(*) as total_records,
    COUNT(CASE WHEN attendance_status = 'UNKNOWN' THEN 1 END) as unprocessed,
    COUNT(CASE WHEN is_half_day = TRUE THEN 1 END) as half_day_records,
    COUNT(CASE WHEN is_late = TRUE THEN 1 END) as late_arrival_records,
    ROUND(AVG(actual_hours_worked), 2) as avg_hours_worked
FROM attendance;

-- ===============================================
-- NOTES FOR IMPLEMENTATION
-- ===============================================

/*
IMPLEMENTATION STEPS:

1. RUN THIS MIGRATION:
   SOURCE add_duty_hours_tracking.sql;

2. USE THE DUTY HOURS SERVICE:
   const dutyHoursService = require('./services/dutyHoursService');
   
   // Recalculate all existing attendance (dry run first)
   await dutyHoursService.recalculateExistingAttendance({ dryRun: true });
   
   // Actually update the records
   await dutyHoursService.recalculateExistingAttendance({ dryRun: false });

3. UPDATE ATTENDANCE CONTROLLER:
   - Import dutyHoursService
   - Call processAttendanceRecord() on new uploads
   - Store calculated values in new columns

4. UPDATE PAYROLL CONTROLLER:
   - Use attendance_status and is_half_day columns
   - Leverage actual_hours_worked for accurate calculations
   - Remove manual half day adjustments

5. BENEFITS:
   - Automated half day detection
   - Consistent payroll calculations  
   - Better audit trail
   - Accurate duty hours tracking
   - Elimination of manual errors

ATTENDANCE STATUS VALUES:
- FULL_DAY: Worked >= required duty hours
- HALF_DAY: Worked < 60% of required hours
- LATE_ARRIVAL: Late but worked full hours
- LATE_AND_HALF_DAY: Late AND insufficient hours
- EARLY_DEPARTURE: Left early but worked full hours  
- EARLY_AND_HALF_DAY: Left early AND insufficient hours
- INSUFFICIENT_HOURS: Didn't work enough (but not late/early)
- ABSENT: No valid punch data
- INVALID_PUNCH: Invalid punch times
- CALCULATION_ERROR: Error in processing

HALF DAY LOGIC:
- Half Day Threshold: < 80% of required duty hours
- Late Threshold: >= 15 minutes after shift start
- Early Threshold: >= 15 minutes before shift end
- Combines timing and duration for accurate classification
*/
