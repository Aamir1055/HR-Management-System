-- Create user_roles table for HRMS system
-- This table stores user role definitions for access control

CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT 'Role name',
  `description` varchar(500) DEFAULT NULL COMMENT 'Role description',
  `isActive` tinyint(1) DEFAULT 1 COMMENT 'Whether role is active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Record creation timestamp',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Record update timestamp',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='User roles for system access control';

-- Insert default roles for recruitment module
INSERT INTO `user_roles` (`name`, `description`, `isActive`) VALUES
('Sales Executive', 'Handles sales and client acquisition', 1),
('Business Development Manager', 'Manages business growth strategies', 1),
('Customer Service Representative', 'Provides customer support', 1),
('Account Manager', 'Manages client accounts', 1),
('Team Leader', 'Leads and coordinates team activities', 1),
('Senior Sales Executive', 'Senior-level sales professional', 1),
('Marketing Executive', 'Manages marketing campaigns', 1),
('Operations Executive', 'Handles operational tasks', 1),
('HR Executive', 'Manages human resources', 1),
('Finance Executive', 'Handles financial operations', 1)
ON DUPLICATE KEY UPDATE
  `description` = VALUES(`description`),
  `updated_at` = CURRENT_TIMESTAMP;
