-- Create Role Master Table
CREATE TABLE `roles` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(100) NOT NULL COMMENT 'Role name',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record update timestamp',
  PRIMARY KEY (`roleId`),
  UNIQUE KEY `unique_role_name` (`roleName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Role master data - stores role information';

-- Insert some default roles
INSERT INTO `roles` (`roleName`) VALUES
('Sales Executive'),
('Business Development Manager'),
('Customer Service Representative'),
('Account Manager'),
('Team Leader'),
('Senior Sales Executive'),
('Marketing Executive'),
('Operations Executive'),
('HR Executive'),
('Finance Executive');

-- Add role column to recruitments table
ALTER TABLE recruitments 
ADD COLUMN role varchar(100) DEFAULT NULL COMMENT 'Role/Position applied for' 
AFTER platform;