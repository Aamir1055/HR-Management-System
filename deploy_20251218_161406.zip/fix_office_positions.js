const mysql = require('mysql2/promise');

const DB_CONFIG = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'payroll_system2'
};

async function fixOfficePositions() {
  const connection = await mysql.createConnection(DB_CONFIG);
  
  try {
    console.log('🔧 FIXING OFFICE-POSITION RELATIONSHIPS');
    console.log('='.repeat(60));
    
    // Step 1: Get all unique office-position combinations from existing employees
    console.log('\n📋 Step 1: Finding office-position combinations from employees');
    const [employeeOfficePositions] = await connection.execute(`
      SELECT DISTINCT 
        e.office_id,
        o.name as office_name,
        e.position_id,
        p.title as position_name
      FROM employees e
      LEFT JOIN offices o ON e.office_id = o.id
      LEFT JOIN positions p ON e.position_id = p.id
      WHERE e.office_id IS NOT NULL 
      AND e.position_id IS NOT NULL
      AND e.office_id != 0 
      AND e.position_id != 0
      ORDER BY o.name, p.title
    `);
    
    console.log(`Found ${employeeOfficePositions.length} unique office-position combinations:`);
    employeeOfficePositions.forEach(ep => {
      console.log(`  - ${ep.office_name} (${ep.office_id}) → ${ep.position_name} (${ep.position_id})`);
    });
    
    if (employeeOfficePositions.length === 0) {
      console.log('❌ No employee office-position relationships found. Cannot proceed.');
      return;
    }
    
    // Step 2: Check existing office_positions table
    console.log('\n📋 Step 2: Checking existing office_positions relationships');
    const [existingRelationships] = await connection.execute(`
      SELECT office_id, position_id FROM office_positions
    `);
    console.log(`Current office_positions table has ${existingRelationships.length} relationships`);
    
    // Create a set of existing relationships for quick lookup
    const existingSet = new Set(
      existingRelationships.map(rel => `${rel.office_id}-${rel.position_id}`)
    );
    
    // Step 3: Insert missing relationships
    console.log('\n📋 Step 3: Adding missing office-position relationships');
    let addedCount = 0;
    
    for (const ep of employeeOfficePositions) {
      const relationshipKey = `${ep.office_id}-${ep.position_id}`;
      
      if (!existingSet.has(relationshipKey)) {
        try {
          await connection.execute(`
            INSERT INTO office_positions (office_id, position_id, reporting_time, duty_hours, created_at)
            VALUES (?, ?, '09:00:00', 8.0, NOW())
          `, [ep.office_id, ep.position_id]);
          
          console.log(`  ✅ Added: ${ep.office_name} → ${ep.position_name}`);
          addedCount++;
        } catch (error) {
          console.log(`  ❌ Failed to add ${ep.office_name} → ${ep.position_name}: ${error.message}`);
        }
      } else {
        console.log(`  ⏭️  Exists: ${ep.office_name} → ${ep.position_name}`);
      }
    }
    
    // Step 4: Verify results
    console.log('\n📋 Step 4: Verification');
    const [finalCount] = await connection.execute('SELECT COUNT(*) as total FROM office_positions');
    console.log(`✅ Total office-position relationships now: ${finalCount[0].total}`);
    console.log(`➕ Added ${addedCount} new relationships`);
    
    // Step 5: Test a few office-position queries
    console.log('\n📋 Step 5: Testing position queries for sample offices');
    
    // Get first 3 office IDs to test
    const [testOffices] = await connection.execute(`
      SELECT DISTINCT office_id, office_name 
      FROM (
        SELECT e.office_id, o.name as office_name
        FROM employees e
        LEFT JOIN offices o ON e.office_id = o.id
        WHERE e.office_id IS NOT NULL AND e.office_id != 0
        LIMIT 3
      ) as sample_offices
    `);
    
    for (const office of testOffices) {
      const [positions] = await connection.execute(`
        SELECT DISTINCT p.id, p.title 
        FROM positions p
        INNER JOIN office_positions op ON p.id = op.position_id
        WHERE op.office_id = ?
        ORDER BY p.title
      `, [office.office_id]);
      
      console.log(`  📍 Office "${office.office_name}" (${office.office_id}): ${positions.length} positions`);
      positions.forEach(pos => console.log(`    - ${pos.title}`));
    }
    
    console.log('\n🎉 OFFICE-POSITION RELATIONSHIPS FIXED!');
    console.log('The position dropdown should now work properly in the employee form.');
    
  } finally {
    await connection.end();
  }
}

fixOfficePositions().catch(console.error);
