/**
 * Test script to create a valid Excel file for employee import debugging
 */

const XLSX = require('xlsx');
const { formatDateForTemplate } = require('./utils/dateUtils');

// Create test employee data with all required fields
const testEmployeeData = [
  {
    'Employee ID': 'EMP001',
    'First Name': 'John',
    'Last Name': 'Doe',
    'Email': 'john.doe@example.com',
    'Office ID': 19, // Use Office ID instead of Office Name
    'Position ID': 21, // Use Position ID instead of Position Name
    'Salary': 4000,
    'Joining Date': formatDateForTemplate('2023-01-01'),
    'Status': 'active',
    
    // Optional fields
    'DOB': formatDateForTemplate('1990-01-15'),
    'Gender': 'Male',
    'Nationality': 'Indian',
    'Phone': '+971501234567',
    'WhatsApp': '+971507891234',
    'Marital Status': 'Single',
    'Primary Language': 'English',
    'Secondary Language': 'Arabic',
    'Passport Number': 'P1234567',
    'Passport Expiry': formatDateForTemplate('2030-01-01'),
    'Visa Type': '1',
    'Visa Expiry': formatDateForTemplate('2030-12-31'),
    'Hiring Source': 'Job Portal',
    'Emergency Contact Relation': 'Father',
    'Current Address': '456 Current Street, Dubai',
    'Platform': '1',
    'Salary Currency': 'AED'
  },
  {
    'Employee ID': 'EMP002', 
    'First Name': 'Jane',
    'Last Name': 'Smith',
    'Email': 'jane.smith@example.com',
    'Office ID': 19,
    'Position ID': 21,
    'Salary': 3500,
    'Joining Date': formatDateForTemplate('2023-02-01'),
    'Status': 'active',
    
    'DOB': formatDateForTemplate('1992-05-20'),
    'Gender': 'Female',
    'Nationality': 'Indian',
    'Phone': '+971509876543',
    'Marital Status': 'Married',
    'Primary Language': 'English'
  }
];

// Also create version with Office Name and Position Name instead of IDs
const testEmployeeDataWithNames = [
  {
    'Employee ID': 'EMP003',
    'First Name': 'Ahmed',
    'Last Name': 'Ali',
    'Email': 'ahmed.ali@example.com',
    'Office Name': 'Head Office', // This should be mapped to office_name
    'Position Name': 'Manager', // This should be mapped to position_name
    'Salary': 5000,
    'Joining Date': formatDateForTemplate('2023-03-01'),
    'Status': 'active',
    
    'DOB': formatDateForTemplate('1985-08-10'),
    'Gender': 'Male',
    'Nationality': 'UAE',
    'Phone': '+971551234567',
    'Primary Language': 'Arabic',
    'Secondary Language': 'English'
  }
];

console.log('Creating test Excel files...');

// Create Excel file with Office/Position IDs
const wb1 = XLSX.utils.book_new();
const ws1 = XLSX.utils.json_to_sheet(testEmployeeData);
XLSX.utils.book_append_sheet(wb1, ws1, 'Employees');
XLSX.writeFile(wb1, './test_employee_import_ids.xlsx');
console.log('Created test_employee_import_ids.xlsx');

// Create Excel file with Office/Position Names 
const wb2 = XLSX.utils.book_new();
const ws2 = XLSX.utils.json_to_sheet(testEmployeeDataWithNames);
XLSX.utils.book_append_sheet(wb2, ws2, 'Employees');
XLSX.writeFile(wb2, './test_employee_import_names.xlsx');
console.log('Created test_employee_import_names.xlsx');

console.log('Test files created successfully!');
console.log('Expected columns for import:', [
  'employeeId', 'first_name', 'last_name', 'email', 'office_name', 
  'position_name', 'monthlySalary', 'joiningDate', 'status'
]);
