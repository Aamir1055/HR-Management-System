const fetch = require('node-fetch');

async function testRolesAPI() {
  try {
    console.log('Testing /api/roles endpoint...');
    
    const response = await fetch('http://localhost:3001/api/roles');
    const data = await response.json();
    
    console.log('Status:', response.status);
    console.log('Response:', JSON.stringify(data, null, 2));
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

testRolesAPI();