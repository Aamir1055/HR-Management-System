-- ===============================================
-- IMPROVED ATTENDANCE ANALYSIS WITH DUTY HOURS
-- ===============================================
-- This addresses the issue where late arrivals with normal departure 
-- times are not being counted as half days properly

-- First, let's create a view to get employee shift details
CREATE OR REPLACE VIEW employee_shift_details AS
SELECT 
    employeeId,
    name,
    monthlySalary,
    shift_timings,
    status,
    CASE 
        WHEN shift_timings LIKE '8:30 AM - 5:30 PM' THEN '08:30:00'
        WHEN shift_timings LIKE '9:00 AM - 6:00 PM' THEN '09:00:00'
        WHEN shift_timings LIKE '9:30 AM - 6:30 PM' THEN '09:30:00'
        ELSE '09:00:00'  -- Default
    END AS shift_start_time,
    CASE 
        WHEN shift_timings LIKE '8:30 AM - 5:30 PM' THEN '17:30:00'
        WHEN shift_timings LIKE '9:00 AM - 6:00 PM' THEN '18:00:00'
        WHEN shift_timings LIKE '9:30 AM - 6:30 PM' THEN '18:30:00'
        ELSE '18:00:00'  -- Default
    END AS shift_end_time,
    CASE 
        WHEN shift_timings LIKE '8:30 AM - 5:30 PM' THEN 9.0  -- 9 hours
        WHEN shift_timings LIKE '9:00 AM - 6:00 PM' THEN 9.0   -- 9 hours  
        WHEN shift_timings LIKE '9:30 AM - 6:30 PM' THEN 9.0   -- 9 hours
        ELSE 9.0  -- Default 9 hours
    END AS required_duty_hours
FROM employees;

-- ===============================================
-- COMPREHENSIVE ATTENDANCE ANALYSIS
-- ===============================================

SELECT 
    a.employee_id,
    e.name,
    a.date,
    a.punch_in,
    a.punch_out,
    e.shift_start_time,
    e.shift_end_time,
    e.required_duty_hours,
    
    -- Calculate actual hours worked
    ROUND(TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600, 2) AS actual_hours_worked,
    
    -- Calculate late minutes
    CASE 
        WHEN a.punch_in > e.shift_start_time 
        THEN TIME_TO_SEC(TIMEDIFF(a.punch_in, e.shift_start_time)) / 60
        ELSE 0 
    END AS late_minutes,
    
    -- Calculate early departure minutes
    CASE 
        WHEN a.punch_out < e.shift_end_time 
        THEN TIME_TO_SEC(TIMEDIFF(e.shift_end_time, a.punch_out)) / 60
        ELSE 0 
    END AS early_departure_minutes,
    
    -- Determine attendance status
    CASE 
        WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.6)
        THEN 'HALF_DAY'
        
        WHEN a.punch_in > ADDTIME(e.shift_start_time, '00:15:00') -- More than 15 min late
        THEN 
            CASE 
                WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
                THEN 'LATE_AND_HALF_DAY'  -- Late + insufficient hours = half day
                ELSE 'LATE_ARRIVAL'
            END
            
        WHEN a.punch_out < SUBTIME(e.shift_end_time, '00:15:00') -- Left more than 15 min early
        THEN 
            CASE 
                WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
                THEN 'EARLY_AND_HALF_DAY'  -- Early departure + insufficient hours = half day
                ELSE 'EARLY_DEPARTURE'
            END
            
        WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 >= e.required_duty_hours
        THEN 'FULL_DAY'
        
        ELSE 'INSUFFICIENT_HOURS'  -- Didn't work enough hours
    END AS attendance_status,
    
    -- Calculate if it should be counted as half day for payroll
    CASE 
        WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
        THEN 1  -- Count as half day
        ELSE 0
    END AS is_half_day,
    
    -- Calculate if it's a late arrival
    CASE 
        WHEN a.punch_in > ADDTIME(e.shift_start_time, '00:15:00')
        THEN 1
        ELSE 0
    END AS is_late
    
FROM attendance a
JOIN employee_shift_details e ON a.employee_id = e.employeeId
WHERE a.date >= '2025-09-01' AND a.date <= '2025-09-30'
ORDER BY a.employee_id, a.date;

-- ===============================================
-- PAYROLL CALCULATION WITH CORRECT LOGIC
-- ===============================================

SELECT 
    a.employee_id,
    e.name,
    e.monthlySalary,
    e.shift_timings,
    
    -- Attendance metrics
    COUNT(a.employee_id) AS present_days,
    (26 - COUNT(a.employee_id)) AS absent_days,
    
    -- Corrected half day calculation
    SUM(CASE 
        WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
        THEN 1 ELSE 0 
    END) AS half_days,
    
    -- Late arrivals (more than 15 minutes)
    SUM(CASE 
        WHEN a.punch_in > ADDTIME(e.shift_start_time, '00:15:00')
        THEN 1 ELSE 0 
    END) AS late_days,
    
    -- Early departures (more than 15 minutes early)
    SUM(CASE 
        WHEN a.punch_out < SUBTIME(e.shift_end_time, '00:15:00')
        THEN 1 ELSE 0 
    END) AS early_departure_days,
    
    -- Average hours worked per day
    ROUND(AVG(TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600), 2) AS avg_hours_per_day,
    
    -- Total insufficient duty hours instances
    SUM(CASE 
        WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
        THEN 1 ELSE 0 
    END) AS insufficient_duty_hours_count,
    
    -- Effective working days for salary calculation
    -- Full days + (Half days * 0.5)
    (COUNT(a.employee_id) - SUM(CASE 
        WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
        THEN 1 ELSE 0 
    END)) + (SUM(CASE 
        WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
        THEN 1 ELSE 0 
    END) * 0.5) AS effective_working_days,
    
    -- Calculated salary based on effective working days
    ROUND(
        e.monthlySalary * (
            (COUNT(a.employee_id) - SUM(CASE 
                WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
                THEN 1 ELSE 0 
            END)) + (SUM(CASE 
                WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
                THEN 1 ELSE 0 
            END) * 0.5)
        ) / 26.0, 2
    ) AS calculated_salary
    
FROM attendance a
JOIN employee_shift_details e ON a.employee_id = e.employeeId
WHERE a.date >= '2025-09-01' AND a.date <= '2025-09-30'
GROUP BY a.employee_id, e.name, e.monthlySalary, e.shift_timings, e.required_duty_hours
ORDER BY a.employee_id;

-- ===============================================
-- SPECIFIC ISSUE EXAMPLES
-- ===============================================

-- Find cases where employee came late but worked normal hours
-- These should be flagged for review
SELECT 
    a.employee_id,
    e.name,
    a.date,
    a.punch_in,
    a.punch_out,
    e.shift_start_time,
    e.shift_end_time,
    TIME_TO_SEC(TIMEDIFF(a.punch_in, e.shift_start_time)) / 60 AS late_minutes,
    TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 AS actual_hours,
    e.required_duty_hours,
    
    CASE 
        WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
        THEN 'HALF_DAY (Insufficient Hours)'
        WHEN a.punch_in > ADDTIME(e.shift_start_time, '00:15:00')
        THEN 'LATE_ARRIVAL'
        ELSE 'NORMAL'
    END AS status_recommendation

FROM attendance a
JOIN employee_shift_details e ON a.employee_id = e.employeeId
WHERE a.date >= '2025-09-01' AND a.date <= '2025-09-30'
    AND (
        -- Late arrival cases
        a.punch_in > ADDTIME(e.shift_start_time, '00:15:00')
        OR 
        -- Insufficient hours cases
        TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in)) / 3600 < (e.required_duty_hours * 0.8)
    )
ORDER BY a.employee_id, a.date;

-- ===============================================
-- PAYROLL MODULE RECOMMENDATIONS
-- ===============================================

/*
RECOMMENDED PAYROLL LOGIC:

1. DUTY HOURS CALCULATION:
   - Get employee shift timings from employee table
   - Calculate required duty hours (usually 8-9 hours)
   - Compare actual worked hours vs required hours

2. ATTENDANCE CLASSIFICATION:
   - FULL_DAY: Worked >= 80% of required hours
   - HALF_DAY: Worked < 80% of required hours  
   - LATE: Arrived > 15 minutes after shift start
   - EARLY_DEPARTURE: Left > 15 minutes before shift end

3. SALARY CALCULATION:
   - Full Days: Count as 1.0
   - Half Days: Count as 0.5
   - Absent Days: Count as 0.0
   - Formula: (Full Days + Half Days * 0.5) / Total Working Days * Monthly Salary

4. EXAMPLE SCENARIOS:
   - Shift: 9:00 AM - 6:00 PM (9 hours required)
   - Came: 9:30 AM, Left: 6:00 PM = 8.5 hours worked
   - Status: LATE + HALF_DAY (because 8.5 < 9*0.8 = 7.2 hours threshold)
   - Pay: 0.5 day salary

5. IMPLEMENTATION IN YOUR HALF-DAY MANAGEMENT:
   - Current half-day shifts (Morning/Afternoon) are for planned half days
   - Unplanned half days due to insufficient hours should be calculated automatically
   - Both should be considered in payroll calculation
*/
