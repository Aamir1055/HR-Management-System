-- Find Employees Without Platform Assignment
-- This script identifies why total count (342) doesn't match platform summary (239)

-- 1. Total employee counts by status
SELECT 'Total Employees Analysis' as report_type,
       CASE 
         WHEN status = 1 THEN 'Active'
         WHEN status = 0 THEN 'Inactive'
         ELSE 'Unknown Status'
       END as status_type,
       COUNT(*) as count
FROM employees 
GROUP BY status
ORDER BY status DESC;

-- 2. Platform assignment analysis
SELECT 'Platform Assignment Analysis' as report_type,
       CASE 
         WHEN platform IS NULL THEN 'NULL Platform'
         WHEN TRIM(platform) = '' THEN 'Empty Platform' 
         WHEN platform = 'All Platform' THEN 'All Platform'
         ELSE 'Has Specific Platform'
       END as platform_status,
       COUNT(*) as total_employees,
       SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as active_employees,
       SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) as inactive_employees
FROM employees 
GROUP BY 
  CASE 
    WHEN platform IS NULL THEN 'NULL Platform'
    WHEN TRIM(platform) = '' THEN 'Empty Platform'
    WHEN platform = 'All Platform' THEN 'All Platform'  
    ELSE 'Has Specific Platform'
  END
ORDER BY total_employees DESC;

-- 3. List employees without platform assignment (first 20)
SELECT 'Unassigned Employees Sample' as report_type,
       employeeId,
       name,
       email,
       office_id,
       position_id,
       status,
       platform,
       joiningDate
FROM employees 
WHERE platform IS NULL 
   OR TRIM(platform) = ''
   OR platform = ''
ORDER BY joiningDate DESC
LIMIT 20;

-- 4. Count by specific platform values
SELECT 'Platform Value Distribution' as report_type,
       COALESCE(NULLIF(TRIM(platform), ''), '[EMPTY/NULL]') as platform_name,
       COUNT(*) as total_employees,
       SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as active_employees
FROM employees 
GROUP BY COALESCE(NULLIF(TRIM(platform), ''), '[EMPTY/NULL]')
ORDER BY total_employees DESC;

-- 5. Verify platform master table
SELECT 'Platform Master Data' as report_type,
       id,
       platform_name,
       'Master Platform' as source
FROM platforms 
ORDER BY platform_name;

-- 6. Current platform summary (what dashboard shows)
SELECT 'Current Dashboard Logic' as report_type,
       p.platform_name as platform,
       COUNT(e.id) as employee_count,
       SUM(e.monthlySalary) as total_salary
FROM platforms p
LEFT JOIN employees e ON p.platform_name = e.platform AND e.status = 1
GROUP BY p.id, p.platform_name
UNION ALL
SELECT 'Current Dashboard Logic' as report_type,
       'TOTAL COUNTED' as platform,
       COUNT(*) as employee_count,
       SUM(monthlySalary) as total_salary
FROM employees e 
JOIN platforms p ON p.platform_name = e.platform 
WHERE e.status = 1
ORDER BY platform;
