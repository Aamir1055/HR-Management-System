/**
 * Fix Offices Query
 * Test and fix the offices API query
 */

const db = require('./db');

async function fixOfficesQuery() {
  console.log('🔍 DIAGNOSING OFFICES API ISSUE');
  console.log('================================\n');

  try {
    // Test 1: Check if offices table exists
    console.log('Test 1: Checking if offices table exists...');
    const [tables] = await db.query("SHOW TABLES LIKE 'offices'");
    if (tables.length === 0) {
      console.log('❌ offices table does NOT exist!');
      console.log('   You need to create the offices table first.\n');
      return;
    }
    console.log('✅ offices table exists\n');

    // Test 2: Check offices table structure
    console.log('Test 2: Checking offices table structure...');
    const [officeColumns] = await db.query('DESCRIBE offices');
    console.log('Offices columns:');
    officeColumns.forEach(col => {
      console.log(`  - ${col.Field} (${col.Type})`);
    });
    console.log('');

    // Test 3: Check if employees table has status column
    console.log('Test 3: Checking employees table for status column...');
    const [empColumns] = await db.query('DESCRIBE employees');
    const hasStatus = empColumns.some(col => col.Field === 'status');
    if (!hasStatus) {
      console.log('⚠️  employees table does NOT have status column');
      console.log('   Using query without status filter...\n');
    } else {
      console.log('✅ employees table has status column\n');
    }

    // Test 4: Try simple query first
    console.log('Test 4: Running simple offices query...');
    const [simpleResults] = await db.query('SELECT * FROM offices LIMIT 5');
    console.log(`✅ Simple query works! Found ${simpleResults.length} offices\n`);

    // Test 5: Try the full query with conditional status
    console.log('Test 5: Running full query with employee summary...');
    
    const statusFilter = hasStatus ? 'WHERE status = 1' : '';
    
    const [fullResults] = await db.query(`
      SELECT 
        o.id as office_id,
        o.name as office_name,
        o.location,
        COALESCE(emp_summary.employeeCount, 0) as employeeCount,
        COALESCE(emp_summary.totalSalary, 0) as totalSalary,
        o.created_at
      FROM offices o
      LEFT JOIN (
        SELECT 
          office_id, 
          COUNT(*) AS employeeCount, 
          SUM(monthlySalary) AS totalSalary 
        FROM employees 
        ${statusFilter}
        GROUP BY office_id
      ) emp_summary ON o.id = emp_summary.office_id
      ORDER BY o.name
    `);
    
    console.log(`✅ Full query works! Found ${fullResults.length} offices\n`);
    
    if (fullResults.length > 0) {
      console.log('Sample data:');
      fullResults.slice(0, 3).forEach(office => {
        console.log(`  - ${office.office_name}`);
        console.log(`    Employees: ${office.employeeCount}, Total Salary: ${office.totalSalary}`);
      });
    }

    console.log('\n\n💡 RECOMMENDATION:');
    console.log('==================\n');
    
    if (!hasStatus) {
      console.log('The employees table is missing the status column.');
      console.log('You should either:');
      console.log('1. Add the status column: ALTER TABLE employees ADD COLUMN status TINYINT DEFAULT 1;');
      console.log('2. Or update the masterController to not filter by status\n');
    } else {
      console.log('The query works fine. The 500 error might be:');
      console.log('1. A different issue in the controller');
      console.log('2. Check your backend console for the actual error message');
      console.log('3. The error might be in how the result is being returned\n');
    }

  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error('SQL State:', error.sqlState);
    console.error('SQL Message:', error.sqlMessage);
    console.error('\nFull error:', error);
  } finally {
    process.exit(0);
  }
}

fixOfficesQuery();
