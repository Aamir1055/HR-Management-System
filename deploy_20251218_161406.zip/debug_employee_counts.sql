-- Employee Count Diagnostic Script
-- Run this script to debug the employee count discrepancies

-- 1. Total employees in database
SELECT 'Total Employees (All)' as description, COUNT(*) as count 
FROM employees;

-- 2. Total active employees only
SELECT 'Total Employees (Active Only)' as description, COUNT(*) as count 
FROM employees WHERE status = 1;

-- 3. Total inactive employees
SELECT 'Total Employees (Inactive Only)' as description, COUNT(*) as count 
FROM employees WHERE status = 0;

-- 4. Platform summary (Active employees only - matching dashboard logic)
SELECT 'Platform Summary (Active Only)' as report_type,
       p.platform_name as platform,
       COUNT(e.id) as employee_count,
       SUM(e.monthlySalary) as total_salary
FROM platforms p
LEFT JOIN employees e ON p.platform_name = e.platform AND e.status = 1
GROUP BY p.id, p.platform_name
ORDER BY p.platform_name;

-- 5. Platform summary (All employees - matching detail view logic)
SELECT 'Platform Summary (All Status)' as report_type,
       p.platform_name as platform,
       COUNT(e.id) as total_employees,
       SUM(CASE WHEN e.status = 1 THEN 1 ELSE 0 END) as active_employees,
       SUM(CASE WHEN e.status = 0 THEN 1 ELSE 0 END) as inactive_employees,
       SUM(e.monthlySalary) as total_salary
FROM platforms p
LEFT JOIN employees e ON p.platform_name = e.platform
GROUP BY p.id, p.platform_name
ORDER BY p.platform_name;

-- 6. Check for employees without platform assignment
SELECT 'Employees without Platform' as description, COUNT(*) as count
FROM employees 
WHERE (platform IS NULL OR platform = '' OR TRIM(platform) = '') AND status = 1;

-- 7. Check platform name mismatches
SELECT 'Platform Name Issues' as report_type,
       e.platform as employee_platform,
       p.platform_name as platform_master,
       COUNT(*) as employee_count
FROM employees e
LEFT JOIN platforms p ON e.platform = p.platform_name
WHERE e.status = 1
GROUP BY e.platform, p.platform_name
HAVING p.platform_name IS NULL AND e.platform IS NOT NULL AND TRIM(e.platform) != '';

-- 8. Specific check for Bazzarfx platform (from your screenshot)
SELECT 'Bazzarfx Platform Analysis' as report_type,
       'All Employees' as status_type,
       COUNT(*) as count
FROM employees 
WHERE platform = 'Bazzarfx'
UNION ALL
SELECT 'Bazzarfx Platform Analysis' as report_type,
       'Active Only' as status_type,
       COUNT(*) as count
FROM employees 
WHERE platform = 'Bazzarfx' AND status = 1
UNION ALL
SELECT 'Bazzarfx Platform Analysis' as report_type,
       'Inactive Only' as status_type,
       COUNT(*) as count
FROM employees 
WHERE platform = 'Bazzarfx' AND status = 0;

-- 9. Check for case sensitivity issues in platform names
SELECT DISTINCT platform, COUNT(*) as count
FROM employees 
WHERE platform IS NOT NULL AND TRIM(platform) != ''
GROUP BY platform
ORDER BY platform;

-- 10. Office-based employee count (to check permission filtering)
SELECT o.name as office_name,
       COUNT(e.id) as total_employees,
       SUM(CASE WHEN e.status = 1 THEN 1 ELSE 0 END) as active_employees
FROM offices o
LEFT JOIN employees e ON o.id = e.office_id
GROUP BY o.id, o.name
ORDER BY o.name;
