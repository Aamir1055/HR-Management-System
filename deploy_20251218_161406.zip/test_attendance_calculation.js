/**
 * Test Attendance Calculation Logic
 * Verifies the new late/half-day calculation works correctly
 */

const { calculateAttendanceMetrics } = require('./utils/attendanceCalculator');

// Test cases for different scenarios
const testCases = [
  {
    name: "On-time full day",
    employee: { shift_timings: "9:00 AM - 6:00 PM" },
    attendance: { punch_in: "09:00", punch_out: "18:00" },
    expected: { is_late: false, is_half_day: false, attendance_status: "PRESENT" }
  },
  {
    name: "1 minute late, but worked 1 minute less (half day)", 
    employee: { shift_timings: "9:00 AM - 6:00 PM" },
    attendance: { punch_in: "09:01", punch_out: "18:00" },
    expected: { is_late: true, is_half_day: true, attendance_status: "HALF_DAY_LATE" }
  },
  {
    name: "On-time but left 1 minute early (half day)",
    employee: { shift_timings: "9:00 AM - 6:00 PM" },
    attendance: { punch_in: "09:00", punch_out: "17:59" },
    expected: { is_late: false, is_half_day: true, attendance_status: "HALF_DAY" }
  },
  {
    name: "Late and half day",
    employee: { shift_timings: "9:00 AM - 6:00 PM" },
    attendance: { punch_in: "09:15", punch_out: "17:30" },
    expected: { is_late: true, is_half_day: true, attendance_status: "HALF_DAY_LATE" }
  },
  {
    name: "Working overtime (late but full day)",
    employee: { shift_timings: "9:00 AM - 6:00 PM" },
    attendance: { punch_in: "09:30", punch_out: "18:30" },
    expected: { is_late: true, is_half_day: false, attendance_status: "PRESENT_LATE" }
  },
  {
    name: "1 minute late but worked full duty hours",
    employee: { shift_timings: "9:00 AM - 6:00 PM" },
    attendance: { punch_in: "09:01", punch_out: "18:01" },
    expected: { is_late: true, is_half_day: false, attendance_status: "PRESENT_LATE" }
  },
  {
    name: "Early arrival, on-time departure",
    employee: { shift_timings: "9:00 AM - 6:00 PM" },
    attendance: { punch_in: "08:30", punch_out: "18:00" },
    expected: { is_late: false, is_half_day: false, attendance_status: "PRESENT" }
  },
  {
    name: "Different shift timing (8 AM - 5 PM)",
    employee: { shift_timings: "8:00 AM - 5:00 PM" },
    attendance: { punch_in: "08:00", punch_out: "17:00" },
    expected: { is_late: false, is_half_day: false, attendance_status: "PRESENT" }
  },
  {
    name: "Different shift - 1 minute late, worked 1 minute less (half day)",
    employee: { shift_timings: "8:00 AM - 5:00 PM" },
    attendance: { punch_in: "08:01", punch_out: "17:00" },
    expected: { is_late: true, is_half_day: true, attendance_status: "HALF_DAY_LATE" }
  },
  {
    name: "No punch data (absent)",
    employee: { shift_timings: "9:00 AM - 6:00 PM" },
    attendance: { punch_in: null, punch_out: null },
    expected: { is_late: false, is_half_day: false, attendance_status: "ABSENT" }
  },
  {
    name: "Invalid punch times (00:00)",
    employee: { shift_timings: "9:00 AM - 6:00 PM" },
    attendance: { punch_in: "00:00", punch_out: "00:00" },
    expected: { is_late: false, is_half_day: false, attendance_status: "ABSENT" }
  }
];

function runTests() {
  console.log('🧪 ATTENDANCE CALCULATION TESTS');
  console.log('=================================\n');

  let passedTests = 0;
  let failedTests = 0;

  testCases.forEach((testCase, index) => {
    console.log(`${index + 1}. ${testCase.name}`);
    console.log(`   Employee Shift: ${testCase.employee.shift_timings}`);
    console.log(`   Punch In/Out: ${testCase.attendance.punch_in || 'N/A'} - ${testCase.attendance.punch_out || 'N/A'}`);
    
    try {
      const result = calculateAttendanceMetrics(testCase.attendance, testCase.employee);
      
      // Check key expectations
      const isLateMatch = result.is_late === testCase.expected.is_late;
      const isHalfDayMatch = result.is_half_day === testCase.expected.is_half_day;
      const statusMatch = result.attendance_status === testCase.expected.attendance_status;
      
      if (isLateMatch && isHalfDayMatch && statusMatch) {
        console.log(`   ✅ PASSED`);
        console.log(`   Result: ${result.attendance_status} | Late: ${result.is_late} | Half Day: ${result.is_half_day}`);
        console.log(`   Hours: ${result.actual_hours_worked}/${result.duty_hours} | Late Minutes: ${result.late_minutes}`);
        passedTests++;
      } else {
        console.log(`   ❌ FAILED`);
        console.log(`   Expected: ${testCase.expected.attendance_status} | Late: ${testCase.expected.is_late} | Half Day: ${testCase.expected.is_half_day}`);
        console.log(`   Got:      ${result.attendance_status} | Late: ${result.is_late} | Half Day: ${result.is_half_day}`);
        console.log(`   Hours: ${result.actual_hours_worked}/${result.duty_hours} | Late Minutes: ${result.late_minutes}`);
        failedTests++;
      }
      
    } catch (error) {
      console.log(`   ❌ ERROR: ${error.message}`);
      failedTests++;
    }
    
    console.log('');
  });

  console.log('📊 TEST SUMMARY');
  console.log('================');
  console.log(`✅ Passed: ${passedTests}`);
  console.log(`❌ Failed: ${failedTests}`);
  console.log(`📋 Total:  ${testCases.length}`);
  
  if (failedTests === 0) {
    console.log('\n🎉 All tests passed! The attendance calculation logic is working correctly.');
  } else {
    console.log(`\n⚠️ ${failedTests} test(s) failed. Please review the calculation logic.`);
  }

  return failedTests === 0;
}

// Test shift timing parsing
function testShiftParsing() {
  console.log('\n🔧 SHIFT TIMING PARSING TESTS');
  console.log('===============================\n');

  const { parseEmployeeShiftTiming } = require('./utils/attendanceCalculator');
  
  const shiftTestCases = [
    { input: "9:00 AM - 6:00 PM", expected: { start24: "09:00", end24: "18:00", dutyHours: 9 }},
    { input: "8:00 AM - 5:00 PM", expected: { start24: "08:00", end24: "17:00", dutyHours: 9 }},
    { input: "10:30 AM - 7:30 PM", expected: { start24: "10:30", end24: "19:30", dutyHours: 9 }},
    { input: null, expected: { start24: "09:00", end24: "18:00", dutyHours: 9 }}, // default
    { input: "", expected: { start24: "09:00", end24: "18:00", dutyHours: 9 }}, // default
  ];

  shiftTestCases.forEach((test, index) => {
    console.log(`${index + 1}. Input: "${test.input || 'null/empty'}"`);
    const result = parseEmployeeShiftTiming(test.input);
    
    const startMatch = result.start24 === test.expected.start24;
    const endMatch = result.end24 === test.expected.end24;
    const hoursMatch = result.dutyHours === test.expected.dutyHours;
    
    if (startMatch && endMatch && hoursMatch) {
      console.log(`   ✅ PASSED: ${result.start24} - ${result.end24} (${result.dutyHours}h)`);
    } else {
      console.log(`   ❌ FAILED`);
      console.log(`   Expected: ${test.expected.start24} - ${test.expected.end24} (${test.expected.dutyHours}h)`);
      console.log(`   Got:      ${result.start24} - ${result.end24} (${result.dutyHours}h)`);
    }
    console.log('');
  });
}

// Run all tests
if (require.main === module) {
  const mainTestsPass = runTests();
  testShiftParsing();
  
  if (mainTestsPass) {
    console.log('\n🚀 Ready to deploy! Run the following commands:');
    console.log('1. node add_duty_hours_column.js    # Add missing column');
    console.log('2. node recalculate_attendance.js   # Update existing records');
    console.log('3. Restart your application server');
  } else {
    console.log('\n⛔ Fix the failing tests before deployment!');
    process.exit(1);
  }
}

module.exports = { runTests, testShiftParsing };
