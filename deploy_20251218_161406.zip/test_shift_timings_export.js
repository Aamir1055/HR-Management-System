/**
 * Test Shift Timings Export/Import
 * Verifies that shift timings are properly exported and imported
 */

const mysql = require('mysql2/promise');
require('dotenv').config();

async function testShiftTimingsExport() {
  const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'payroll_system2',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

  try {
    console.log('🧪 TESTING SHIFT TIMINGS EXPORT/IMPORT');
    console.log('======================================');
    console.log('');

    // Test 1: Check if shift_timings column exists
    console.log('📋 Checking if shift_timings column exists...');
    const [columns] = await pool.query('DESCRIBE employees');
    const shiftTimingsColumn = columns.find(col => col.Field === 'shift_timings');
    
    if (shiftTimingsColumn) {
      console.log('   ✅ shift_timings column exists');
      console.log(`   Type: ${shiftTimingsColumn.Type}`);
      console.log(`   Nullable: ${shiftTimingsColumn.Null}`);
    } else {
      console.log('   ❌ shift_timings column NOT FOUND!');
      console.log('   You may need to add it to the employees table');
      return;
    }

    // Test 2: Check if any employees have shift timings
    console.log('\n📊 Checking existing shift timings data...');
    const [employeesWithShifts] = await pool.query(`
      SELECT COUNT(*) as count 
      FROM employees 
      WHERE shift_timings IS NOT NULL AND shift_timings != ''
    `);
    
    console.log(`   Employees with shift timings: ${employeesWithShifts[0].count}`);

    // Test 3: Show sample shift timings
    const [sampleEmployees] = await pool.query(`
      SELECT employeeId, first_name, last_name, shift_timings 
      FROM employees 
      WHERE shift_timings IS NOT NULL AND shift_timings != ''
      LIMIT 5
    `);
    
    if (sampleEmployees.length > 0) {
      console.log('\n   Sample shift timings:');
      sampleEmployees.forEach(emp => {
        console.log(`   - ${emp.employeeId} (${emp.first_name} ${emp.last_name}): ${emp.shift_timings}`);
      });
    } else {
      console.log('   ℹ️ No employees have shift timings set yet');
    }

    // Test 4: Check if shift timings is in the export mapping
    console.log('\n🔍 Checking Employee model mappings...');
    const { EmployeeFieldMappings } = require('./models/Employee');
    
    const shiftTimingsMappings = Object.entries(EmployeeFieldMappings.excelToModel)
      .filter(([key, value]) => value === 'shift_timings');
    
    if (shiftTimingsMappings.length > 0) {
      console.log('   ✅ Shift timings is mapped in Employee model');
      console.log('   Excel column names that map to shift_timings:');
      shiftTimingsMappings.forEach(([key]) => {
        console.log(`     - "${key}"`);
      });
    } else {
      console.log('   ❌ Shift timings NOT mapped in Employee model!');
    }

    // Test 5: Update a test employee with shift timings
    console.log('\n🔧 Testing shift timings update...');
    const [testEmployee] = await pool.query('SELECT employeeId FROM employees LIMIT 1');
    
    if (testEmployee && testEmployee[0]) {
      const testEmpId = testEmployee[0].employeeId;
      const testShiftTimings = '09:00-18:00';
      
      await pool.query(
        'UPDATE employees SET shift_timings = ? WHERE employeeId = ?',
        [testShiftTimings, testEmpId]
      );
      
      const [updated] = await pool.query(
        'SELECT shift_timings FROM employees WHERE employeeId = ?',
        [testEmpId]
      );
      
      if (updated[0].shift_timings === testShiftTimings) {
        console.log(`   ✅ Successfully updated employee ${testEmpId} with shift timings: ${testShiftTimings}`);
      } else {
        console.log('   ❌ Failed to update shift timings');
      }
    }

    console.log('\n✅ SHIFT TIMINGS TEST COMPLETED!');
    console.log('================================');
    console.log('Summary:');
    console.log('1. ✅ shift_timings column exists in database');
    console.log('2. ✅ shift_timings is mapped in Employee model');
    console.log('3. ✅ shift_timings can be updated in database');
    console.log('');
    console.log('💡 NEXT STEPS:');
    console.log('1. Export employees to Excel - shift timings should now be included');
    console.log('2. Edit shift timings in Excel');
    console.log('3. Import the Excel file - shift timings should be updated');

  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await pool.end();
  }
}

testShiftTimingsExport();