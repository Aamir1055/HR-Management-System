/**
 * Test Status Conversion
 * Verifies that "Active" and "Inactive" are properly converted
 */

console.log('🧪 TESTING STATUS CONVERSION');
console.log('============================');
console.log('');

// Test different status values
const testCases = [
  { input: 'Active', expected: 1 },
  { input: 'active', expected: 1 },
  { input: 'ACTIVE', expected: 1 },
  { input: ' Active ', expected: 1 },
  { input: 'Inactive', expected: 0 },
  { input: 'inactive', expected: 0 },
  { input: 'INACTIVE', expected: 0 },
  { input: ' Inactive ', expected: 0 },
  { input: 1, expected: 1 },
  { input: 0, expected: 0 },
  { input: true, expected: 1 },
  { input: false, expected: 0 },
];

console.log('📋 Testing Status Conversions:');
console.log('');

let allPassed = true;

testCases.forEach(({ input, expected }) => {
  // Simulate the conversion logic
  let status = 1; // Default to active
  if (input !== undefined && input !== null) {
    if (typeof input === 'string') {
      const statusLower = input.trim().toLowerCase();
      status = statusLower === 'active' ? 1 : 0;
    } else {
      status = input ? 1 : 0;
    }
  }
  
  const passed = status === expected;
  const icon = passed ? '✅' : '❌';
  const inputDisplay = typeof input === 'string' ? `"${input}"` : input;
  
  console.log(`${icon} Input: ${inputDisplay.toString().padEnd(15)} → ${status} (expected: ${expected})`);
  
  if (!passed) allPassed = false;
});

console.log('');
console.log('📊 RESULT');
console.log('=========');

if (allPassed) {
  console.log('✅ All status conversions work correctly!');
  console.log('');
  console.log('Your Excel with "Active" and "Inactive" will be imported correctly.');
  console.log('');
  console.log('🔄 IMPORTANT: Restart your backend server!');
  console.log('   1. Stop the backend (Ctrl+C)');
  console.log('   2. Run: npm start');
  console.log('   3. Import your Excel file');
  console.log('   4. Check backend console for status debug logs');
} else {
  console.log('❌ Some status conversions failed!');
}

console.log('');
console.log('💡 Expected Behavior:');
console.log('   "Active" → 1 (active in database)');
console.log('   "Inactive" → 0 (inactive in database)');
console.log('   Case-insensitive and trims whitespace');