-- Add Platform column to recruitments table
ALTER TABLE recruitments 
ADD COLUMN platform varchar(100) DEFAULT NULL COMMENT 'Trading platform (National Stock Exchange, Forex)' 
AFTER recruitmentPipeline;