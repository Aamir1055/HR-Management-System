// Test the date validation fix
const { Recruitment } = require('./models/Recruitment');

console.log('🔍 Testing Date Validation Fix\n');

// Test cases
const testCases = [
  {
    name: 'Valid DD/MM/YYYY format',
    date: '27/09/2025',
    expected: true
  },
  {
    name: 'Valid DD/MM/YYYY format (today)',
    date: new Date().toLocaleDateString('en-GB'),
    expected: true
  },
  {
    name: 'Invalid format',
    date: '2025-09-27',
    expected: true // This should still work as ISO format
  },
  {
    name: 'Invalid date',
    date: '32/13/2025',
    expected: false
  },
  {
    name: 'Empty date',
    date: '',
    expected: false
  }
];

testCases.forEach((testCase, index) => {
  console.log(`\n${index + 1}. Testing: ${testCase.name}`);
  console.log(`   Input: "${testCase.date}"`);
  
  const recruitment = new Recruitment({
    date: testCase.date,
    fullName: 'Test User',
    mobile: '1234567890',
    email: 'test@example.com',
    recruitmentSource: 'LinkedIn',
    recruitmentPipeline: 'Application Received',
    nationality: 'UAE'
  });
  
  const validation = recruitment.validate();
  const isValid = validation.isValid;
  const hasDateError = validation.errors.some(error => error.includes('date format'));
  
  console.log(`   Result: ${isValid ? '✅ Valid' : '❌ Invalid'}`);
  if (validation.errors.length > 0) {
    console.log(`   Errors: ${validation.errors.join(', ')}`);
  }
  
  const passed = (isValid === testCase.expected) || (testCase.expected === false && hasDateError);
  console.log(`   Test: ${passed ? '✅ PASSED' : '❌ FAILED'}`);
});

console.log('\n🎯 Testing DB Format Conversion:');

const recruitment = new Recruitment({
  date: '27/09/2025',
  fullName: 'Test User',
  mobile: '1234567890',
  email: 'test@example.com',
  recruitmentSource: 'LinkedIn',
  recruitmentPipeline: 'Application Received',
  nationality: 'UAE'
});

const dbFormat = recruitment.toDbFormat();
console.log(`Original date: "${recruitment.date}"`);
console.log(`DB format date: "${dbFormat.date}"`);
console.log(`Expected: "2025-09-27"`);
console.log(`Conversion: ${dbFormat.date === '2025-09-27' ? '✅ CORRECT' : '❌ INCORRECT'}`);

console.log('\n✨ Test complete!');
