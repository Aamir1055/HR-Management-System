-- ===============================================
-- ATTENDANCE DATA VERIFICATION QUERIES
-- ===============================================
-- Use these queries to verify and analyze the generated attendance data

-- 1. BASIC VERIFICATION
-- Check total records and employee coverage
SELECT 
    COUNT(*) AS total_records,
    COUNT(DISTINCT employee_id) AS unique_employees,
    MIN(date) AS start_date,
    MAX(date) AS end_date
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30';

-- 2. ATTENDANCE SUMMARY BY EMPLOYEE
-- Show attendance stats for each employee
SELECT 
    employee_id,
    COUNT(*) AS present_days,
    ROUND(AVG(TIME_TO_SEC(TIMEDIFF(punch_out, punch_in))/3600), 2) AS avg_hours_per_day,
    MIN(punch_in) AS earliest_in,
    MAX(punch_out) AS latest_out
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30'
GROUP BY employee_id
ORDER BY employee_id;

-- 3. ATTENDANCE DISTRIBUTION
-- Show how many employees have different attendance levels
SELECT 
    present_days,
    COUNT(*) AS employee_count
FROM (
    SELECT 
        employee_id,
        COUNT(*) AS present_days
    FROM attendance 
    WHERE date >= '2025-09-01' AND date <= '2025-09-30'
    GROUP BY employee_id
) AS emp_attendance
GROUP BY present_days
ORDER BY present_days;

-- 4. DAILY ATTENDANCE SUMMARY
-- Show attendance count for each day
SELECT 
    date,
    DAYNAME(date) AS day_name,
    COUNT(*) AS employees_present
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30'
GROUP BY date
ORDER BY date;

-- 5. IDENTIFY HALF DAYS
-- Find potential half-day records (less than 6 hours)
SELECT 
    employee_id,
    date,
    punch_in,
    punch_out,
    TIME_TO_SEC(TIMEDIFF(punch_out, punch_in))/3600 AS hours_worked
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30'
    AND TIME_TO_SEC(TIMEDIFF(punch_out, punch_in))/3600 < 6
ORDER BY employee_id, date;

-- 6. IDENTIFY LATE ARRIVALS
-- Find late arrivals (after 9:15 AM for 9 AM shift, after 8:45 AM for 8:30 AM shift)
SELECT 
    employee_id,
    date,
    punch_in,
    'Late Arrival' AS attendance_issue
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30'
    AND (
        (employee_id IN (1, 2) AND punch_in > '08:45:00')  -- 8:30 AM shift employees
        OR 
        (employee_id NOT IN (1, 2) AND punch_in > '09:15:00')  -- 9:00 AM shift employees
    )
ORDER BY employee_id, date;

-- 7. WEEKEND VERIFICATION
-- Verify no attendance on Sundays
SELECT 
    date,
    DAYNAME(date) AS day_name,
    COUNT(*) AS records_count
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30'
    AND DAYNAME(date) = 'Sunday'
GROUP BY date;

-- 8. MISSING EMPLOYEES
-- Find employees from your employee table who have no attendance
SELECT 
    e.employeeId,
    e.name,
    e.status,
    'No Attendance' AS issue
FROM employees e
LEFT JOIN attendance a ON e.employeeId = a.employee_id 
    AND a.date >= '2025-09-01' AND a.date <= '2025-09-30'
WHERE a.employee_id IS NULL
ORDER BY e.employeeId;

-- 9. EMPLOYEES WITH MINIMAL ATTENDANCE (Likely Inactive)
-- Find employees with very low attendance (≤5 days)
SELECT 
    employee_id,
    COUNT(*) AS present_days,
    'Minimal Attendance' AS status
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30'
GROUP BY employee_id
HAVING COUNT(*) <= 5
ORDER BY present_days, employee_id;

-- 10. PAYROLL CALCULATION PREVIEW
-- Calculate basic payroll metrics for first 10 employees
SELECT 
    a.employee_id,
    e.name,
    e.monthlySalary,
    COUNT(a.employee_id) AS present_days,
    (26 - COUNT(a.employee_id)) AS absent_days,
    SUM(CASE 
        WHEN TIME_TO_SEC(TIMEDIFF(a.punch_out, a.punch_in))/3600 < 6 
        THEN 1 ELSE 0 
    END) AS half_days,
    SUM(CASE 
        WHEN (a.employee_id IN (1, 2) AND a.punch_in > '08:45:00')
             OR (a.employee_id NOT IN (1, 2) AND a.punch_in > '09:15:00')
        THEN 1 ELSE 0 
    END) AS late_days,
    ROUND(
        e.monthlySalary * (COUNT(a.employee_id) / 26.0), 2
    ) AS calculated_salary
FROM attendance a
JOIN employees e ON a.employee_id = e.employeeId
WHERE a.date >= '2025-09-01' AND a.date <= '2025-09-30'
    AND a.employee_id <= 10
GROUP BY a.employee_id, e.name, e.monthlySalary
ORDER BY a.employee_id;

-- 11. PERFORMANCE SUMMARY
-- Overall system performance metrics
SELECT 
    'Total Working Days' AS metric, '26' AS value
UNION ALL
SELECT 
    'Total Employees', CAST(COUNT(DISTINCT employee_id) AS CHAR)
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30'
UNION ALL
SELECT 
    'Total Attendance Records', CAST(COUNT(*) AS CHAR)
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30'
UNION ALL
SELECT 
    'Average Attendance per Employee', 
    CAST(ROUND(COUNT(*) / COUNT(DISTINCT employee_id), 1) AS CHAR)
FROM attendance 
WHERE date >= '2025-09-01' AND date <= '2025-09-30'
UNION ALL
SELECT 
    'Perfect Attendance Count',
    CAST(COUNT(*) AS CHAR)
FROM (
    SELECT employee_id
    FROM attendance 
    WHERE date >= '2025-09-01' AND date <= '2025-09-30'
    GROUP BY employee_id
    HAVING COUNT(*) = 26
) AS perfect_attendance;

-- ===============================================
-- NOTES FOR PAYROLL TESTING
-- ===============================================

/*
TESTING SCENARIOS COVERED:

1. PERFECT ATTENDANCE (26 days)
   - Calculate full monthly salary
   - Test: monthlySalary * 1.0

2. NORMAL ATTENDANCE (24-25 days)
   - Calculate pro-rated salary
   - Test: monthlySalary * (present_days / 26)

3. HALF DAYS
   - Deduct half day from salary
   - Test: (present_days - 0.5 * half_days) / 26 * monthlySalary

4. LATE ARRIVALS
   - Apply late penalties if applicable
   - Test: late_penalty * late_days

5. INACTIVE EMPLOYEES (2-5 days)
   - Calculate very low attendance
   - Test edge cases in payroll calculation

6. LEAVE CALCULATIONS
   - Unpaid leave deductions
   - Test: (26 - present_days) = leave_days

VALIDATION CHECKLIST:
□ No Sunday attendance records
□ All employee IDs from 1-354 covered
□ Realistic punch times (8:30-9:30 AM in, 5:30-6:30 PM out)
□ Half days show early punch-out
□ Late arrivals show delayed punch-in
□ Total records around 7,900-8,500
□ Inactive employees have 2-5 attendance days
□ Active employees have 24-26 attendance days
*/
