const mysql = require('mysql2/promise');
const XLSX = require('xlsx');

// Simulate the exact export function
const testExport = async () => {
  const pool = mysql.createPool({
    host: 'localhost',
    user: 'payroll_app', 
    password: 'payroll123',
    database: 'payroll_system2',
    waitForConnections: true,
    connectionLimit: 1,
  });

  try {
    console.log('🔍 Testing Cloud Export Function...');
    
    let sql = `
      SELECT e.*, o.name AS office_name, p.title AS position_title,
             op.reporting_time, op.duty_hours, e.visa_type AS visa_type_name
      FROM employees e
      LEFT JOIN offices o ON e.office_id = o.id
      LEFT JOIN positions p ON e.position_id = p.id
      LEFT JOIN office_positions op ON e.office_id = op.office_id AND e.position_id = op.position_id
      ORDER BY CAST(e.employeeId AS UNSIGNED), e.employeeId
      LIMIT 5
    `;
    
    const [employees] = await pool.query(sql);
    console.log(`📊 Retrieved ${employees.length} employees`);
    
    // Helper function to format dates to DD/MM/YYYY for export
    const formatDateForExport = (dateStr) => {
      if (!dateStr) return '';
      
      try {
        let date;
        
        // Handle different input formats
        if (typeof dateStr === 'string') {
          // If it's already in YYYY-MM-DD format (from database)
          if (dateStr.match(/^\d{4}-\d{2}-\d{2}$/)) {
            const [year, month, day] = dateStr.split('-');
            return `${day}/${month}/${year}`;
          }
          // If it's in YYYY/MM/DD format
          else if (dateStr.match(/^\d{4}\/\d{2}\/\d{2}$/)) {
            const [year, month, day] = dateStr.split('/');
            return `${day}/${month}/${year}`;
          }
          // If it's already in DD/MM/YYYY format, return as is
          else if (dateStr.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
            return dateStr;
          }
          // Try to parse as a general date
          else {
            date = new Date(dateStr);
          }
        } else {
          date = new Date(dateStr);
        }
        
        // If we have a valid date object, format it
        if (date && !isNaN(date.getTime())) {
          const day = date.getDate().toString().padStart(2, '0');
          const month = (date.getMonth() + 1).toString().padStart(2, '0');
          const year = date.getFullYear();
          return `${day}/${month}/${year}`;
        }
        
        return dateStr; // Return original if can't format
      } catch (error) {
        console.warn(`Warning: Could not format date '${dateStr}':`, error.message);
        return dateStr;
      }
    };
    
    // Format data for export - EXACT columns in EXACT order as requested (removed Full Name)
    console.log('🚀 Using NEW Excel export with 25 columns and auto-filters!');
    const exportData = employees.map(emp => ({
      'Employee ID': emp.employeeId,
      'First Name': emp.first_name || '',
      'Last Name': emp.last_name || '',
      'Date of Birth': formatDateForExport(emp.dob),
      'Date of Joining': formatDateForExport(emp.joiningDate),
      'Nationality': emp.nationality || '',
      'Passport Number': emp.passport_number || '',
      'Passport Expiry': formatDateForExport(emp.passport_expiry),
      'Visa Type': emp.visa_type_name || emp.visa_type || '',
      'Visa Expiry': formatDateForExport(emp.visa_expiry),
      'Office': emp.office_name || '',
      'Platform': emp.platform || '',
      'Position': emp.position_title || '',
      'Monthly Salary': emp.monthlySalary || 0,
      'Email': emp.email || '',
      'Phone': emp.phone || '',
      'WhatsApp': emp.whatsapp || '',
      'Gender': emp.gender || '',
      'Marital Status': emp.marital_status || '',
      'Primary Language': emp.primary_language || '',
      'Secondary Language': emp.secondary_language || '',
      'Hiring Source': emp.hiring_source || '',
      'Current Address': emp.current_address || '',
      'Emergency Contact Relation': emp.emergency_contact_relation || '',
      'Emergency Contact': emp.emergency_contact || '',
      'Status': emp.status === 1 ? 'Active' : 'Inactive'
    }));
    
    console.log('\n📋 Column Headers Generated:');
    if (exportData[0]) {
      const headers = Object.keys(exportData[0]);
      headers.forEach((header, index) => {
        console.log(`${index + 1}. ${header}`);
      });
      console.log(`\n✅ Total Columns: ${headers.length}`);
      
      console.log('\n📝 Sample Data (First Employee):');
      console.log(exportData[0]);
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    await pool.end();
  }
};

testExport();
