const mysql = require('mysql2/promise');
require('dotenv').config();

async function testService() {
  const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'payroll_system2',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

  try {
    console.log('Testing RoleService...');
    
    const RoleRepository = require('./repositories/RoleRepository');
    const RoleService = require('./services/RoleService');
    
    const roleRepo = new RoleRepository(pool);
    const roleService = new RoleService(roleRepo);
    
    console.log('Testing getAllRoles()...');
    const result = await roleService.getAllRoles();
    console.log('✅ Service result:', JSON.stringify(result, null, 2));
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error('Stack:', error.stack);
  } finally {
    await pool.end();
  }
}

testService();