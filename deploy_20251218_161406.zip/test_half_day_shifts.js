/**
 * Test Half-Day Shift Detection
 * Simple test script to verify the half-day shift detection functionality
 */

const { detectHalfDayShift, getHalfDayShifts } = require('./utils/attendanceCalculator');
require('dotenv').config();

const testHalfDayShiftDetection = async () => {
  try {
    console.log('🧪 Testing Half-Day Shift Detection...\n');
    
    // Test 1: Get all active half-day shifts
    console.log('1️⃣ Fetching active half-day shifts...');
    const shifts = await getHalfDayShifts();
    console.log(`Found ${shifts.length} active half-day shifts:`);
    shifts.forEach(shift => {
      console.log(`  - ${shift.shift_name}: ${shift.start_time} - ${shift.end_time} (min ${shift.min_hours}h)`);
    });
    console.log();
    
    if (shifts.length === 0) {
      console.log('⚠️ No half-day shifts configured. Please add some shifts to test the detection.');
      return;
    }
    
    // Test 2: Test with sample punch times that should match a shift
    console.log('2️⃣ Testing punch time matching...');
    
    // Use the first shift as an example
    const testShift = shifts[0];
    const testStartTime = testShift.start_time;
    const testEndTime = testShift.end_time;
    const minHours = parseFloat(testShift.min_hours);
    
    // Test case 1: Exact match
    console.log(`\nTest Case 1 - Exact match with "${testShift.shift_name}":`);
    console.log(`  Punch In: ${testStartTime}, Punch Out: ${testEndTime}, Hours: ${minHours}`);
    
    const result1 = await detectHalfDayShift(testStartTime, testEndTime, minHours);
    if (result1) {
      console.log(`  ✅ DETECTED: ${result1.shiftName} - Planned Half Day: ${result1.isPlannedHalfDay}`);
    } else {
      console.log(`  ❌ NOT DETECTED`);
    }
    
    // Test case 2: Within tolerance (15 minutes late start, 15 minutes early end)
    console.log(`\nTest Case 2 - Within tolerance (+15min start, -15min end):`);
    const lateStart = addMinutes(testStartTime, 15);
    const earlyEnd = addMinutes(testEndTime, -15);
    console.log(`  Punch In: ${lateStart}, Punch Out: ${earlyEnd}, Hours: ${minHours - 0.5}`);
    
    const result2 = await detectHalfDayShift(lateStart, earlyEnd, minHours - 0.5);
    if (result2) {
      console.log(`  ✅ DETECTED: ${result2.shiftName} - Planned Half Day: ${result2.isPlannedHalfDay}`);
    } else {
      console.log(`  ❌ NOT DETECTED`);
    }
    
    // Test case 3: Outside tolerance (should not match)
    console.log(`\nTest Case 3 - Outside tolerance (+45min start, -45min end):`);
    const veryLateStart = addMinutes(testStartTime, 45);
    const veryEarlyEnd = addMinutes(testEndTime, -45);
    console.log(`  Punch In: ${veryLateStart}, Punch Out: ${veryEarlyEnd}, Hours: ${minHours - 1.5}`);
    
    const result3 = await detectHalfDayShift(veryLateStart, veryEarlyEnd, minHours - 1.5);
    if (result3) {
      console.log(`  ❌ UNEXPECTED DETECTION: ${result3.shiftName}`);
    } else {
      console.log(`  ✅ CORRECTLY NOT DETECTED`);
    }
    
    // Test case 4: Not enough hours (should not match)
    console.log(`\nTest Case 4 - Not enough hours worked:`);
    console.log(`  Punch In: ${testStartTime}, Punch Out: ${testEndTime}, Hours: ${minHours - 1}`);
    
    const result4 = await detectHalfDayShift(testStartTime, testEndTime, minHours - 1);
    if (result4) {
      console.log(`  ❌ UNEXPECTED DETECTION: ${result4.shiftName}`);
    } else {
      console.log(`  ✅ CORRECTLY NOT DETECTED (insufficient hours)`);
    }
    
    console.log('\n🎉 Half-day shift detection test completed!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error(error.stack);
  }
};

// Helper function to add/subtract minutes from time string
function addMinutes(timeStr, minutes) {
  const [hours, mins, secs] = timeStr.split(':').map(Number);
  const totalMinutes = hours * 60 + mins + minutes;
  const newHours = Math.floor(totalMinutes / 60);
  const newMins = totalMinutes % 60;
  return `${String(newHours).padStart(2, '0')}:${String(newMins).padStart(2, '0')}:${String(secs || 0).padStart(2, '0')}`;
}

// Run test if called directly
if (require.main === module) {
  testHalfDayShiftDetection().catch(console.error);
}

module.exports = testHalfDayShiftDetection;
