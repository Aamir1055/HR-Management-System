/**
 * Test Offices API
 * Check if the offices endpoint is working
 */

const db = require('./db');

async function testOfficesAPI() {
  console.log('🔍 TESTING OFFICES API QUERY');
  console.log('============================\n');

  try {
    console.log('Running the same query as getAllOffices...\n');
    
    const [results] = await db.query(`
      SELECT 
        o.id as office_id,
        o.name as office_name,
        o.location,
        COALESCE(emp_summary.employeeCount, 0) as employeeCount,
        COALESCE(emp_summary.totalSalary, 0) as totalSalary,
        o.created_at
      FROM offices o
      LEFT JOIN (
        SELECT 
          office_id, 
          COUNT(*) AS employeeCount, 
          SUM(monthlySalary) AS totalSalary 
        FROM employees 
        WHERE status = 1
        GROUP BY office_id
      ) emp_summary ON o.id = emp_summary.office_id
      ORDER BY o.name
    `);
    
    console.log(`✅ Query successful! Found ${results.length} offices\n`);
    
    if (results.length > 0) {
      console.log('Sample offices:');
      results.slice(0, 5).forEach(office => {
        console.log(`  - ${office.office_name} (ID: ${office.office_id})`);
        console.log(`    Location: ${office.location || 'N/A'}`);
        console.log(`    Employees: ${office.employeeCount}`);
        console.log('');
      });
    } else {
      console.log('⚠️  No offices found in database');
    }
    
    // Check if offices table exists
    console.log('\n📊 Checking offices table structure...\n');
    const [columns] = await db.query('DESCRIBE offices');
    console.log('Offices table columns:');
    columns.forEach(col => {
      console.log(`  - ${col.Field} (${col.Type})`);
    });
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error('Stack:', error.stack);
  } finally {
    process.exit(0);
  }
}

testOfficesAPI();
